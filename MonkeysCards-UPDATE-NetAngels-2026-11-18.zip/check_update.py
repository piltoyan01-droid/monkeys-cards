"""Read-only offline preflight. Never imports the bot or accesses credentials."""

import argparse
import hashlib
import json
from pathlib import Path
import sys


class CheckFailed(ValueError):
    pass


def source_hash(data: bytes) -> str:
    return hashlib.sha256(data.replace(b"\r\n", b"\n")).hexdigest()


def check_package(package: Path) -> dict:
    metadata = json.loads((package / "BUILD_INFO.json").read_text(encoding="utf-8"))
    for relative, expected in metadata["files_sha256"].items():
        path = (package / relative).resolve()
        if not path.is_relative_to(package.resolve()):
            raise CheckFailed("INVALID_PACKAGE_PATH")
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise CheckFailed("PACKAGE_CHECKSUM_MISMATCH")
    if (package / "update" / ".env").exists():
        raise CheckFailed("UNEXPECTED_ENV_FILE_IN_UPDATE")
    if (package / "update" / "assets" / "inline_stickers.json").exists():
        raise CheckFailed("UNEXPECTED_STICKER_MANIFEST_IN_UPDATE")
    return metadata


def check_target(target: Path, expected_hash: str) -> None:
    main = target / "main.py"
    if not main.is_file() or source_hash(main.read_bytes()) != expected_hash:
        raise CheckFailed("BASE_MAIN_MISMATCH")
    games = target / "games.json"
    if games.exists():
        if json.loads(games.read_text(encoding="utf-8-sig")) != {}:
            raise CheckFailed("SAVED_GAMES_NOT_EMPTY")


def main() -> int:
    parser = argparse.ArgumentParser(description="Offline check before updating the existing Monkeys Cards installation.")
    parser.add_argument("target", type=Path, help="Existing bot directory containing main.py")
    args = parser.parse_args()
    if sys.version_info[:2] != (3, 12):
        print("CHECK_FAILED PYTHON_3_12_REQUIRED")
        return 1
    try:
        metadata = check_package(Path(__file__).resolve().parent)
        check_target(args.target, metadata["base_main_normalized_sha256"])
    except CheckFailed as error:
        print(f"CHECK_FAILED {error}")
        return 1
    except (OSError, ValueError, KeyError, TypeError):
        print("CHECK_FAILED UNREADABLE_OR_INVALID_FILES")
        return 1
    print("CHECK_OK package_intact base_matches saved_games_empty")
    print("READ_ONLY: no files changed, no Telegram requests, no bot process started.")
    print("Before copying: stop the existing service and keep its BOT_TOKEN and startup configuration.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
