"""Offline checks for the production configuration and entry-point behavior."""

import os
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import unittest
from unittest.mock import AsyncMock, patch

import config
import main as bot_main


class ServerConfigurationTests(unittest.TestCase):
    def setUp(self):
        self.token = "123456:" + "X" * 35

    def test_existing_service_env_wins_over_stale_dotenv_without_reading_it(self):
        with patch.dict(os.environ, {"BOT_TOKEN": self.token}, clear=True):
            with patch.object(config, "dotenv_values", side_effect=AssertionError("must not read .env")):
                settings = config.load_settings()
        self.assertEqual(settings.token, self.token)
        self.assertEqual(settings.username, "monkeysmafcardsbot")
        self.assertNotIn(self.token, repr(settings))

    def test_explicit_username_is_checked_with_the_existing_service_token(self):
        with patch.dict(os.environ, {"BOT_TOKEN": self.token, "BOT_USERNAME": " @ExampleBot "}, clear=True):
            self.assertEqual(config.load_settings().username, "ExampleBot")

    def test_dotenv_fallback_uses_only_the_release_directory(self):
        with TemporaryDirectory() as directory:
            path = Path(directory)
            (path / ".env").write_text(f"BOT_TOKEN={self.token}\n", encoding="utf-8")
            with patch.dict(os.environ, {}, clear=True), patch.object(config, "ROOT", path):
                settings = config.load_settings()
        self.assertEqual(settings.token, self.token)
        self.assertEqual(settings.username, "monkeysmafcardsbot")

    def test_missing_token_fails_without_printing_credentials(self):
        with patch.dict(os.environ, {}, clear=True), patch.object(config, "dotenv_values", return_value={}):
            with self.assertRaises(config.ConfigurationError) as raised:
                config.load_settings()
        self.assertIn("BOT_TOKEN", str(raised.exception))

    def test_invalid_environment_token_never_falls_back_to_another_bot(self):
        secret = "OFFLINE_INVALID_SECRET"
        with patch.dict(os.environ, {"BOT_TOKEN": secret}, clear=True):
            with patch.object(config, "dotenv_values", side_effect=AssertionError("must not fall back")):
                with self.assertRaises(config.ConfigurationError) as raised:
                    config.load_settings()
        self.assertNotIn(secret, str(raised.exception))


class ProductionWelcomeTests(unittest.IsolatedAsyncioTestCase):
    async def test_group_start_explains_game_instead_of_dealing_demo_cards(self):
        message = SimpleNamespace(answer=AsyncMock())
        before = dict(bot_main.views)
        await bot_main.welcome(message)
        text = message.answer.call_args.args[0]
        self.assertIn("MONKEYS CARDS", text)
        self.assertIn("/game", text)
        self.assertNotIn("эксперимент", text)
        self.assertNotIn("LAB", text)
        self.assertEqual(bot_main.views, before)

    async def test_private_start_keeps_welcome_and_settings_access(self):
        message = SimpleNamespace(text="/start", from_user=SimpleNamespace(id=123), answer=AsyncMock())
        await bot_main.settings_ui.start(message, AsyncMock())
        text = message.answer.call_args.args[0]
        self.assertIn("MONKEYS CARDS", text)
        self.assertIn("/game", text)
        self.assertIn("/mysettings", text)


if __name__ == "__main__":
    unittest.main()
