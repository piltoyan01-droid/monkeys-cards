"""Offline checks for group-only delivery and privacy boundaries. No real token."""

import asyncio
from datetime import datetime, timezone
from types import SimpleNamespace
import logging
import unittest
from unittest.mock import AsyncMock, patch

from aiogram.exceptions import TelegramBadRequest, TelegramNetworkError
from aiogram.methods import SendMessage
from aiogram.types import CallbackQuery, Chat, Message, User

import main as lab
import configure


def query(user_id=101, data="lab:open", chat_id=-100123, ephemeral_id=None, receiver=None):
    message = Message(
        message_id=0 if ephemeral_id is not None else 42,
        date=datetime.now(timezone.utc),
        chat=Chat(id=chat_id, type="supergroup" if chat_id < 0 else "private"),
        ephemeral_message_id=ephemeral_id, receiver_user=receiver,
    )
    return CallbackQuery(
        id="offline-callback", from_user=User(id=user_id, is_bot=False, first_name="Tester"),
        chat_instance="offline-group", message=message, data=data,
    )


class ExperimentTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        lab.views.clear()
        self.bot = AsyncMock()
        self.bot.send_message.return_value = SimpleNamespace(ephemeral_message_id=700)
        self.bot.answer_callback_query.return_value = True

    async def asyncTearDown(self):
        tasks = list(lab.receipt_tasks)
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        lab.receipt_tasks.clear()
        lab.views.clear()

    async def open(self, user_id=101, chat_id=-100123):
        callback = query(user_id=user_id, chat_id=chat_id).as_(self.bot)
        await lab.open_hand(callback, self.bot)
        return lab.views.get((chat_id, user_id))

    async def click(self, view, action="seen", user_id=101, nonce=None, ephemeral_id=700):
        data = f"lab:{action}:{nonce or view.nonce}"
        if action == "select":
            data += ":2"
        callback = query(user_id=user_id, data=data, ephemeral_id=ephemeral_id).as_(self.bot)
        await lab.update_hand(callback, self.bot)

    async def test_send_is_real_ephemeral_in_original_group(self):
        view = await self.open()
        args = self.bot.send_message.call_args.kwargs
        self.assertEqual(args["chat_id"], -100123)
        self.assertEqual(args["ephemeral_message_parameters"].receiver_user_id, 101)
        self.assertEqual(args["ephemeral_message_parameters"].callback_query_id, "offline-callback")
        self.assertEqual(len(set(view.cards)), 5)
        self.assertTrue(set(view.cards) <= set(lab.DECK))
        self.assertEqual(len(args["reply_markup"].inline_keyboard), 6)
        self.assertFalse(view.seen)  # API success is not delivery confirmation.

    async def test_private_chat_never_receives_hand(self):
        self.assertIsNone(await self.open(chat_id=101))
        self.bot.send_message.assert_not_awaited()

    async def test_card_selection_uses_ephemeral_edit(self):
        view = await self.open()
        await self.click(view, "select")
        args = self.bot.edit_ephemeral_message_text.call_args.kwargs
        self.assertEqual(args["receiver_user_id"], 101)
        self.assertEqual(args["ephemeral_message_id"], 700)
        self.assertIn(view.cards[2], args["text"])
        self.assertEqual(view.selected, 2)
        self.assertTrue(view.seen)
        self.assertEqual(self.bot.send_message.await_count, 1)
        self.bot.edit_message_text.assert_not_awaited()

    async def test_other_user_cannot_edit_hand(self):
        view = await self.open()
        await self.click(view, "select", user_id=202)
        self.bot.edit_ephemeral_message_text.assert_not_awaited()
        self.assertFalse(view.seen)

    async def test_old_window_cannot_edit_current_hand(self):
        view = await self.open()
        await self.click(view, "select", nonce="expired")
        await self.click(view, "select", ephemeral_id=701)
        self.bot.edit_ephemeral_message_text.assert_not_awaited()

    async def test_send_failure_never_falls_back_to_public_or_dm(self):
        for error in (TelegramBadRequest(method=SendMessage(chat_id=-100123, text="test"), message="test"),
                      TelegramNetworkError(method=SendMessage(chat_id=-100123, text="test"), message="test")):
            with self.subTest(error=type(error).__name__):
                self.bot.send_message.reset_mock()
                self.bot.send_message.side_effect = error
                self.assertIsNone(await self.open())
                self.assertEqual(self.bot.send_message.await_count, 1)
                self.assertEqual(self.bot.send_message.call_args.kwargs["chat_id"], -100123)

    async def test_edit_failure_keeps_hand_private(self):
        view = await self.open()
        self.bot.edit_ephemeral_message_text.side_effect = TelegramBadRequest(
            method=SendMessage(chat_id=-100123, text="test"), message="expired")
        await self.click(view, "select")
        self.assertEqual(self.bot.send_message.await_count, 1)
        self.bot.edit_message_text.assert_not_awaited()

    async def test_each_group_and_user_gets_separate_state(self):
        a = await self.open()
        b = await self.open(user_id=202)
        c = await self.open(chat_id=-100456)
        self.assertEqual(len(lab.views), 3)
        self.assertEqual(len({a.nonce, b.nonce, c.nonce}), 3)

    async def test_identity_mismatch_stops_before_polling_or_webhook_changes(self):
        self.bot.get_me.return_value = SimpleNamespace(username="production_bot")
        with self.assertRaises(ValueError):
            await lab.check_identity(self.bot, "new_lab_bot")
        self.bot.get_webhook_info.assert_not_awaited()
        self.bot.delete_webhook.assert_not_awaited()

    async def test_existing_webhook_is_never_deleted(self):
        self.bot.get_me.return_value = SimpleNamespace(username="new_lab_bot")
        self.bot.get_webhook_info.return_value = SimpleNamespace(url="https://example.invalid/hook")
        with self.assertRaises(ValueError):
            await lab.check_identity(self.bot, "new_lab_bot")
        self.bot.delete_webhook.assert_not_awaited()

    async def test_receipt_timeout_does_not_claim_delivery_or_reveal_cards(self):
        view = await self.open()
        with patch.object(lab.asyncio, "sleep", new=AsyncMock()), self.assertLogs(lab.LOG, level="INFO") as logs:
            await lab.watch_receipt(view)
        self.assertIn("delivery_unconfirmed", logs.output[0])
        self.assertFalse(view.seen)
        self.assertTrue(all(card not in logs.output[0] for card in view.cards))

    async def test_framework_diagnostics_never_print_exception_text(self):
        secret = "OFFLINE_SENTINEL_SECRET"
        record = logging.LogRecord(
            "aiogram.dispatcher", logging.ERROR, "", 0,
            "Failed to fetch updates - %s: %s", ("TelegramNetworkError", secret), None)
        with self.assertLogs(lab.LOG, level="WARNING") as logs:
            lab.SafeFrameworkHandler().emit(record)
        self.assertNotIn(secret, "".join(logs.output))
        self.assertIn("TelegramNetworkError", logs.output[0])


class SetupTests(unittest.TestCase):
    def test_configuration_paste_strips_outer_whitespace(self):
        fake_token = "123456:" + "X" * 35
        with patch("pathlib.Path.write_text") as write:
            configure.save_settings(" @new_lab_bot ", f"\r\n{fake_token}\n")
        self.assertEqual(write.call_args.args[0], f"BOT_TOKEN={fake_token}\nBOT_USERNAME=new_lab_bot\n")

    def test_invalid_paste_does_not_overwrite_env_or_echo_secret(self):
        with patch("pathlib.Path.write_text") as write:
            with self.assertRaises(ValueError) as raised:
                configure.save_settings("new_lab_bot", "OFFLINE_SENTINEL_SECRET")
        write.assert_not_called()
        self.assertNotIn("OFFLINE_SENTINEL_SECRET", str(raised.exception))


if __name__ == "__main__":
    unittest.main()
