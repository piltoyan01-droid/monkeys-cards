"""Original game rules and a full mixed ephemeral/inline party, without Telegram."""

import asyncio
from pathlib import Path
from types import SimpleNamespace
import unittest
from tempfile import TemporaryDirectory
from unittest.mock import AsyncMock, patch

from aiogram.exceptions import TelegramNetworkError
from aiogram.methods import SendMessage
from aiogram.types import CallbackQuery, Chat, ChosenInlineResult, InlineQuery, Message, User
from datetime import datetime, timezone

import main as lab
from card_selection import ConfirmedMove, DECK
from game_flow import GameFlow
from inline_mode import InlineLab
from match_engine import MatchError, MatchManager
from public_turn import PublicLab, PublicTurnError
from group_settings import GroupSettings
from test_experiment import query


class MatchRuleTests(unittest.TestCase):
    def game(self, count=2):
        store = MatchManager()
        game = store.create(-100123, None, 101, "Player 1")
        for index in range(1, count):
            store.join(game, 101 + index, f"Player {index + 1}")
        return store, game

    def test_registration_limits_duplicate_join_and_start_permissions(self):
        store, game = self.game(1)
        with self.assertRaises(MatchError):
            store.start(game, 101, "group")
        with self.assertRaises(MatchError):
            store.join(game, 101, "Duplicate")
        for index in range(1, 5):
            store.join(game, 101 + index, f"P{index}")
        with self.assertRaises(MatchError):
            store.join(game, 999, "Sixth")
        with self.assertRaises(MatchError):
            store.start(game, 102, "group")
        store.start(game, 101, "group")
        with self.assertRaises(MatchError):
            store.join(game, 999, "Late")

    def test_deals_and_full_parties_for_each_registered_player_count(self):
        for count in range(2, 6):
            with self.subTest(players=count):
                store, game = self.game(count)
                store.start(game, 101, "group")
                dealt = [card for hand in game.hands.values() for card in hand]
                self.assertEqual(len(dealt), count * 5)
                self.assertEqual(len(set(dealt)), len(dealt))
                self.assertEqual(game.total_turns, count * 5)
                for turn_index in range(game.total_turns):
                    author = 101 + turn_index % count
                    voter = 101 + (turn_index + 1) % count
                    self.assertEqual(game.author.user_id, author)
                    self.assertEqual(game.voter.user_id, voter)
                    real = game.hands[author][0]
                    declared = real if turn_index % 2 == 0 else DECK[(DECK.index(real) + 1) % 36]
                    move = ConfirmedMove(real, declared, real == declared)
                    token = f"turn-{turn_index}"
                    store.reserve(game.chat_id, game.token, turn_index, author, token, move)
                    self.assertEqual(sum(map(len, game.hands.values())) + 1, count * 5)
                    vote = "yes" if turn_index % 3 else "no"
                    before = {uid: len(hand) for uid, hand in game.hands.items()}
                    receiver = author if ((vote == "yes") == (real == declared)) else voter
                    store.complete(game.chat_id, game.token, token, voter, vote)
                    self.assertEqual(len(game.hands[receiver]), before[receiver] + 1)
                    self.assertEqual(sum(map(len, game.hands.values())), count * 5)
                    store.complete(game.chat_id, game.token, token, voter, vote)
                    self.assertEqual(game.turns_done, turn_index + 1)
                self.assertEqual(game.status, "finished")
                self.assertEqual(set(game.turns_by_player.values()), {5})
                self.assertEqual(sum(map(len, game.hands.values())), count * 5)

    def test_only_current_author_and_designated_responder_can_act(self):
        store, game = self.game(3)
        store.start(game, 101, "group")
        real = game.hands[101][0]
        for user in (102, 103, 999):
            with self.subTest(user=user), self.assertRaises(MatchError):
                store.reserve(game.chat_id, game.token, 0, user, "x", ConfirmedMove(real, real, True))
        store.reserve(game.chat_id, game.token, 0, 101, "x", ConfirmedMove(real, real, True))
        for user in (101, 103, 999):
            with self.subTest(voter=user), self.assertRaises(MatchError):
                store.complete(game.chat_id, game.token, "x", user, "yes")
        self.assertEqual(game.turns_done, 0)

    def test_stale_context_absent_card_and_parallel_move_are_rejected(self):
        store, game = self.game()
        store.start(game, 101, "group")
        with self.assertRaises(MatchError):
            store.validate_selection(game.chat_id, 101, None, None)
        with self.assertRaises(MatchError):
            store.validate_selection(game.chat_id, 101, game.token, 1)
        absent = next(card for card in DECK if card not in game.hands[101])
        with self.assertRaises(MatchError):
            store.reserve(game.chat_id, game.token, 0, 101, "bad", ConfirmedMove(absent, absent, True))
        real = game.hands[101][0]
        store.reserve(game.chat_id, game.token, 0, 101, "x", ConfirmedMove(real, real, True))
        with self.assertRaises(MatchError):
            store.reserve(game.chat_id, game.token, 0, 101, "again", ConfirmedMove(real, real, True))

    def test_lowest_card_count_wins_and_equal_counts_are_tied(self):
        store, game = self.game(3)
        game.hands = {101: list(DECK[:3]), 102: list(DECK[3:9]), 103: list(DECK[9:12])}
        ranking = store.ranking(game)
        self.assertEqual([p.user_id for p, count in ranking if count == ranking[0][1]], [101, 103])

    def play_truth(self, store, game):
        author, voter = game.author.user_id, game.voter.user_id
        real = game.hands[author][0]
        token = f"turn-{game.turns_done}"
        store.reserve(game.chat_id, game.token, game.turns_done, author, token, ConfirmedMove(real, real, True))
        store.complete(game.chat_id, game.token, token, voter, "yes")

    def test_leave_lobby_transfers_creator_and_last_player_closes_registration(self):
        store, game = self.game(2)
        with self.assertRaises(MatchError):
            store.leave(game, 999)
        result = store.leave(game, 101)
        self.assertTrue(result.creator_changed)
        self.assertEqual(game.creator_id, 102)
        self.assertEqual(game.status, "lobby")
        store.leave(game, 102)
        self.assertEqual(game.status, "stopped")

    def test_leaving_after_played_turns_keeps_rounds_and_five_moves_for_remaining_players(self):
        for count in range(3, 6):
            with self.subTest(count=count):
                store, game = self.game(count)
                store.start(game, 101, "group")
                for _ in range(count + 1):
                    self.play_truth(store, game)
                old_total, played = game.total_turns, game.turns_done
                unplayed = 5 - game.turns_by_player[101]
                store.leave(game, 101)
                self.assertEqual(game.total_turns, old_total - unplayed)
                self.assertEqual(game.turns_done, played)
                self.assertNotIn(101, game.hands)
                while game.status == "active":
                    self.assertEqual(game.current_round, game.remaining_turns[0].round_number)
                    self.assertNotEqual(game.author.user_id, 101)
                    self.play_truth(store, game)
                self.assertEqual(game.status, "finished")
                self.assertEqual(set(game.turns_by_player.values()), {5})
                self.assertEqual(game.total_turns, game.turns_done)
                self.assertEqual(sum(map(len, game.hands.values())), (count - 1) * 5)

    def test_leaving_pending_voter_returns_card_and_invalidates_old_context(self):
        store, game = self.game(3)
        store.start(game, 101, "group")
        old_token = game.token
        real = game.hands[101][0]
        store.reserve(game.chat_id, game.token, 0, 101, "pending", ConfirmedMove(real, real, True))
        outcome = store.leave(game, 102)
        self.assertTrue(outcome.cancelled_move)
        self.assertIsNone(game.pending)
        self.assertEqual(len(game.hands[101]), 5)
        self.assertEqual(game.author.user_id, 101)
        self.assertEqual(game.voter.user_id, 103)
        with self.assertRaises(MatchError):
            store.find(game.chat_id, old_token)
        self.play_truth(store, game)
        self.assertEqual(game.turns_done, 1)

    def test_leaving_pending_author_withdraws_table_card_and_advances_author(self):
        store, game = self.game(3)
        store.start(game, 101, "group")
        real = game.hands[101][0]
        store.reserve(game.chat_id, game.token, 0, 101, "pending", ConfirmedMove(real, real, True))
        store.leave(game, 101)
        self.assertEqual(game.author.user_id, 102)
        self.assertEqual(game.voter.user_id, 103)
        self.assertIsNone(game.pending)
        self.assertEqual(game.total_turns, 10)
        self.assertEqual(sum(map(len, game.hands.values())), 10)

    def test_unrelated_player_can_leave_without_cancelling_pending_move(self):
        store, game = self.game(3)
        store.start(game, 101, "group")
        token, real = game.token, game.hands[101][0]
        store.reserve(game.chat_id, token, 0, 101, "pending", ConfirmedMove(real, real, True))
        outcome = store.leave(game, 103)
        self.assertFalse(outcome.cancelled_move)
        self.assertEqual(game.token, token)
        self.assertEqual(game.pending.token, "pending")
        store.complete(game.chat_id, token, "pending", 102, "yes")
        self.assertEqual(game.author.user_id, 102)
        self.assertEqual(game.total_turns, 10)

    def test_leaving_with_less_than_two_stops_and_last_scheduled_author_can_finish_party(self):
        store, game = self.game(2)
        store.start(game, 101, "group")
        store.leave(game, 101)
        self.assertEqual(game.status, "stopped")
        self.assertIsNone(store.ongoing(game.chat_id))
        store, game = self.game(3)
        store.start(game, 101, "group")
        for _ in range(14):
            self.play_truth(store, game)
        self.assertEqual(game.author.user_id, 103)
        store.leave(game, 103)
        self.assertEqual(game.status, "finished")
        self.assertEqual(game.total_turns, 14)
        self.assertEqual(len(game.players), 2)


class RegisteredGameTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.matches = MatchManager()
        self.public = PublicLab(Path("offline-assets"), self.matches)
        self.inline = InlineLab(lambda: self.public, lab.current_cards)
        self.inline.faces.ids = {card: f"offline-face-{index}" for index, card in enumerate(DECK)}
        self.flow = GameFlow(self.matches, lambda: self.public, self.inline, lab.close_private_view)
        self.public.after_game_turn = self.flow.after_turn
        self.replacements = [patch.object(lab, "matches", self.matches),
                             patch.object(lab, "public_lab", self.public), patch.object(lab, "inline_lab", self.inline),
                             patch.object(lab, "game_flow", self.flow)]
        for replacement in self.replacements:
            replacement.start()
            self.addCleanup(replacement.stop)
        lab.views.clear()
        self.bot = AsyncMock()
        self.counter = 100
        self.bot.send_message.side_effect = self.sent
        self.bot.send_rich_message.side_effect = self.sent
        self.bot.send_sticker.side_effect = self.sent

    async def asyncTearDown(self):
        tasks = list(lab.receipt_tasks)
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        lab.receipt_tasks.clear()
        lab.views.clear()

    async def sent(self, **kwargs):
        self.counter += 1
        return SimpleNamespace(message_id=self.counter, ephemeral_message_id=self.counter,
                               sticker=SimpleNamespace(file_id=f"offline-{self.counter}"))

    async def start(self, count=2):
        game = self.matches.create(-100123, None, 101, "Author")
        for index in range(1, count):
            self.matches.join(game, 101 + index, f"P{index + 1}")
        self.matches.start(game, 101, "offline-group")
        await self.flow.announce_turn(self.bot, game)
        return game

    def normal_callback(self, data, user_id=101, message_id=42, ephemeral_id=None):
        callback = query(user_id=user_id, data=data, ephemeral_id=ephemeral_id)
        message = callback.message.model_copy(update={"message_id": message_id})
        return callback.model_copy(update={"message": message}).as_(self.bot)

    def inline_callback(self, data, user_id, inline_id):
        return CallbackQuery(id="test-callback", from_user=User(id=user_id, is_bot=False, first_name="Tester"),
                             chat_instance="offline-group", inline_message_id=inline_id, data=data).as_(self.bot)

    def command(self, text, user_id=101):
        return Message(message_id=10, date=datetime.now(timezone.utc),
                       chat=Chat(id=-100123, type="supergroup"),
                       from_user=User(id=user_id, is_bot=False, first_name=f"Player {user_id}"),
                       text=text).as_(self.bot)

    async def test_lobby_handlers_register_then_start_and_show_both_selection_buttons(self):
        await self.flow.create_game(self.command("/game"), self.bot)
        self.assertTrue(self.bot.send_message.call_args.kwargs["link_preview_options"].is_disabled)
        game = self.matches.games[-100123]
        self.assertEqual([player.user_id for player in game.players], [101])
        await self.flow.lobby_action(self.normal_callback(f"game:join:{game.token}", 102, game.lobby_id), self.bot)
        self.assertEqual(len(game.players), 2)
        await self.flow.lobby_action(self.normal_callback(f"game:begin:{game.token}", 102, game.lobby_id), self.bot)
        self.assertEqual(game.status, "lobby")
        await self.flow.lobby_action(self.normal_callback(f"game:begin:{game.token}", 101, game.lobby_id), self.bot)
        self.assertEqual(game.status, "active")
        panel = self.bot.send_rich_message.call_args.kwargs
        roles = panel["rich_message"].blocks[1].text
        self.assertEqual((roles[1].user.id, roles[1].text), (101, "Player 101"))
        self.assertEqual((roles[3].user.id, roles[3].text), (102, "Tester"))
        self.assertEqual(panel["rich_message"].blocks[-1].text[0].user.id, 101)
        details = next(block for block in panel["rich_message"].blocks if block.type == "details")
        self.assertFalse(details.is_open)
        self.assertEqual(len(panel["reply_markup"].inline_keyboard), 2)
        self.assertFalse(any("Назад" in button.text for row in panel["reply_markup"].inline_keyboard for button in row))

    async def test_stop_handler_requires_administrator(self):
        game = await self.start()
        self.bot.get_chat_member.return_value = SimpleNamespace(status="member")
        await self.flow.stop(self.command("/stop"), self.bot)
        self.assertEqual(game.status, "active")
        self.bot.get_chat_member.return_value = SimpleNamespace(status="administrator")
        await self.flow.stop(self.command("/stop"), self.bot)
        self.assertEqual(game.status, "stopped")

    async def test_leave_lobby_updates_registration_and_transfers_start_permission(self):
        await self.flow.create_game(self.command("/game"), self.bot)
        game = self.matches.ongoing(-100123)
        self.matches.join(game, 102, "P2")
        self.matches.join(game, 103, "P3")
        await self.flow.leave(self.command("/leave", 101), self.bot)
        self.assertEqual([player.user_id for player in game.players], [102, 103])
        self.assertEqual(game.creator_id, 102)
        edited = self.bot.edit_message_text.call_args.kwargs
        self.assertIn("Игроков: 2/5", edited["text"])
        self.assertTrue(edited["link_preview_options"].is_disabled)
        await self.flow.lobby_action(self.normal_callback(f"game:begin:{game.token}", 102, game.lobby_id), self.bot)
        self.assertEqual(game.status, "active")

    async def test_leave_current_voter_cancels_pending_move_and_party_can_continue(self):
        game = await self.start(3)
        turn = await self.ephemeral_move(game)
        await self.flow.leave(self.command("/leave", 102), self.bot)
        self.assertIsNone(game.pending)
        self.assertEqual(game.author.user_id, 101)
        self.assertEqual(game.voter.user_id, 103)
        self.assertEqual(len(game.hands[101]), 5)
        self.assertNotIn((game.chat_id, 101), lab.views)
        await self.vote(turn, 103)
        self.assertIsNone(turn.vote)
        fresh = await self.inline_move(game)
        await self.vote(fresh, 103)
        self.assertEqual(game.turns_done, 1)

    async def test_leave_unrelated_player_preserves_current_vote(self):
        game = await self.start(3)
        turn = await self.ephemeral_move(game)
        await self.flow.leave(self.command("/leave", 103), self.bot)
        self.assertEqual(game.pending.token, turn.token)
        await self.vote(turn, 102)
        self.assertEqual(game.turns_done, 1)
        self.assertEqual(game.total_turns, 10)
        self.assertEqual(game.author.user_id, 102)

    async def test_leave_with_two_players_stops_without_winner_and_outsider_cannot_leave(self):
        game = await self.start()
        await self.flow.leave(self.command("/leave", 999), self.bot)
        self.assertEqual(len(game.players), 2)
        await self.flow.leave(self.command("/leave", 101), self.bot)
        self.assertEqual(game.status, "stopped")
        self.assertIsNone(game.final_message_id)
        self.assertIsNone(self.matches.ongoing(game.chat_id))
        await self.flow.create_game(self.command("/game", 102), self.bot)
        self.assertIsNot(self.matches.ongoing(game.chat_id), game)

    async def test_leave_keeps_an_already_accepted_vote_counted_and_reports_missing_result(self):
        game = await self.start(3)
        turn = await self.ephemeral_move(game)
        self.public.accept_vote(turn, 102, "P2", False, "yes")
        await self.flow.leave(self.command("/leave", 103), self.bot)
        self.assertTrue(turn.match_applied)
        self.assertIsNotNone(turn.result_id)
        self.assertEqual(game.turns_done, 1)
        self.assertEqual(game.author.user_id, 102)
        self.assertIsNone(game.pending)
        self.assertEqual(sum(map(len, game.hands.values())), 10)
        notification = self.bot.call_args.args[0]
        self.assertIn("Карта открыта!", notification.text)
        self.assertTrue(notification.link_preview_options.is_disabled)

    async def test_game_command_recovers_failed_announcement_after_leave(self):
        game = await self.start(3)
        self.bot.send_rich_message.side_effect = TelegramNetworkError(
            method=SendMessage(chat_id=game.chat_id, text="test"), message="offline")
        with self.assertRaises(TelegramNetworkError):
            await self.flow.leave(self.command("/leave", 103), self.bot)
        self.assertEqual(len(game.players), 2)
        self.assertNotIn(0, game.announcements)
        self.bot.send_rich_message.side_effect = self.sent
        await self.flow.create_game(self.command("/game", 101), self.bot)
        self.assertIs(self.matches.ongoing(game.chat_id), game)
        self.assertIn(0, game.announcements)

    async def test_full_party_after_leave_preserves_round_labels_and_finishes_remaining_players(self):
        game = await self.start(3)
        for _ in range(4):
            turn = await self.ephemeral_move(game)
            await self.vote(turn, game.voter.user_id)
        await self.flow.leave(self.command("/leave", 103), self.bot)
        self.assertEqual(game.current_round, 2)
        self.assertEqual(game.total_turns, 11)
        header = self.bot.send_rich_message.call_args.kwargs["rich_message"].blocks[0].text.text
        self.assertEqual(header, "Круг 2/5 · Ход 5/11")
        while game.status == "active":
            turn = await self.inline_move(game)
            await self.vote(turn, game.voter.user_id)
        self.assertEqual(game.turns_done, 11)
        self.assertEqual(set(game.turns_by_player.values()), {5})
        self.assertEqual(sum(map(len, game.hands.values())), 10)
        self.assertIn("Ходов сыграно: 11/11", self.bot.send_message.call_args.kwargs["text"])

    async def test_managed_inline_reveal_uses_cached_face_and_only_one_keyboard_update(self):
        game = await self.start()
        turn = await self.inline_move(game)
        self.bot.edit_message_reply_markup.reset_mock()
        await self.vote(turn, 102)
        self.assertEqual(self.bot.edit_message_reply_markup.await_count, 1)
        self.assertIsInstance(self.bot.send_sticker.call_args.kwargs["sticker"], str)
        self.assertTrue(turn.inline_finished_updated)

    def draft(self, game):
        panel = next(panel for panel in self.inline.panels.values()
                     if panel.match_id == game.token and panel.match_turn == game.turns_done)
        query_ = InlineQuery(id="inline-query", from_user=User(id=101, is_bot=False, first_name="Tester"),
                             query=f"lab4 {panel.token}", offset="", chat_type="supergroup")
        result = self.inline.build_results(query_)[0]
        return self.inline.get_proposal(result.id, 101)

    async def test_ephemeral_back_closes_private_view_without_moving_cards(self):
        game = await self.start()
        hands = {user: list(cards) for user, cards in game.hands.items()}
        await lab.open_hand(self.normal_callback(f"lab3:game:{game.token}:0", message_id=game.announcements[0]), self.bot)
        view = lab.views[(game.chat_id, 101)]
        data = f"lab3:select:{view.nonce}:{view.revision}:0"
        await lab.update_selection(self.normal_callback(data, ephemeral_id=view.ephemeral_id), self.bot)
        view = lab.views[(game.chat_id, 101)]
        back = next(button for row in lab.hand_keyboard(view).inline_keyboard for button in row
                    if button.text == "Назад к выбору режима")
        self.bot.send_message.reset_mock()
        await lab.update_selection(self.normal_callback(back.callback_data, ephemeral_id=view.ephemeral_id), self.bot)
        self.assertNotIn((game.chat_id, 101), lab.views)
        self.bot.delete_ephemeral_message.assert_awaited_once()
        self.bot.send_message.assert_not_awaited()
        self.assertEqual(game.hands, hands)
        self.assertIsNone(game.pending)
        self.assertEqual(game.turns_done, 0)
        await lab.update_selection(self.normal_callback(data, ephemeral_id=view.ephemeral_id), self.bot)
        self.assertNotIn((game.chat_id, 101), lab.views)
        proposal, session = self.draft(game)
        self.assertEqual(session.cards, tuple(hands[101]))

    async def test_group_back_invalidates_inline_choice_and_allows_other_mode(self):
        game = await self.start()
        hands = {user: list(cards) for user, cards in game.hands.items()}
        proposal, session = self.draft(game)
        self.bot.send_message.reset_mock()
        back = self.normal_callback(f"game:back:{game.token}:0", message_id=game.announcements[0])
        await self.flow.back_action(back, self.bot)
        self.assertEqual(session.phase, "cancelled")
        await self.inline.on_callback(self.inline_callback(f"lab4:confirm:{proposal.token}", 101, "old-choice"), self.bot)
        self.assertIsNone(game.pending)
        self.assertEqual(game.hands, hands)
        self.bot.send_message.assert_not_awaited()
        await lab.open_hand(self.normal_callback(f"lab3:game:{game.token}:0", message_id=game.announcements[0]), self.bot)
        self.assertEqual(lab.views[(game.chat_id, 101)].cards, tuple(hands[101]))

    async def test_inline_cancel_hides_declared_card_and_returns_modes(self):
        game = await self.start()
        hands = {user: list(cards) for user, cards in game.hands.items()}
        proposal, session = self.draft(game)
        keyboard = self.inline.claim_keyboard(proposal.token)
        self.assertEqual([row[0].text for row in keyboard.inline_keyboard], ["Подтвердить ход", "Отмена"])
        self.bot.send_message.reset_mock()
        await self.inline.on_callback(self.inline_callback(f"lab4:cancel:{proposal.token}", 101, "final-choice"), self.bot)
        edit = self.bot.edit_message_text.call_args.kwargs
        self.assertEqual(edit["text"], "Выбор отменен.")
        self.assertEqual(edit["inline_message_id"], "final-choice")
        self.assertEqual(session.phase, "cancelled")
        self.assertEqual(game.hands, hands)
        self.assertIsNone(game.pending)
        self.bot.edit_message_reply_markup.assert_awaited()
        self.bot.send_message.assert_not_awaited()

    async def test_inline_open_adds_back_only_after_mode_selected(self):
        game = await self.start()
        proposal, session = self.draft(game)
        query_ = InlineQuery(id="inline-query", from_user=User(id=101, is_bot=False, first_name="Tester"),
                             query=f"lab4 {session.panel.token}", offset="", chat_type="supergroup").as_(self.bot)
        self.bot.send_message.reset_mock()
        await self.inline.answer_query(query_)
        args = self.bot.edit_message_reply_markup.call_args.kwargs
        self.assertEqual(args["message_id"], game.announcements[0])
        self.assertEqual([row[0].text for row in args["reply_markup"].inline_keyboard],
                         ["Скинуть карту", "Назад к выбору режима"])
        self.bot.send_message.assert_not_awaited()
        await self.flow.return_to_modes(self.bot, game, 101)
        args = self.bot.edit_message_reply_markup.call_args.kwargs
        self.assertEqual([row[0].text for row in args["reply_markup"].inline_keyboard],
                         ["Скинуть карту", "Мои карты"])

    async def test_back_rejects_other_player_wrong_source_and_committed_turn(self):
        game = await self.start()
        proposal, session = self.draft(game)
        data = f"game:back:{game.token}:0"
        for callback in (self.normal_callback(data, 102, game.announcements[0]),
                         self.normal_callback(data, 101, 999),
                         self.normal_callback(f"game:back:{game.token}:1", 101, game.announcements[0])):
            await self.flow.back_action(callback, self.bot)
            self.assertEqual(session.phase, "choosing")
        self.bot.edit_message_reply_markup.assert_not_awaited()
        turn = await self.inline_move(game)
        self.bot.edit_message_reply_markup.reset_mock()
        await self.flow.back_action(self.normal_callback(data, 101, game.announcements[0]), self.bot)
        self.assertEqual(session.phase, "confirmed")
        self.assertIsNotNone(game.pending)
        self.bot.edit_message_reply_markup.assert_not_awaited()

    async def test_statistics_expose_counts_but_no_hand_contents(self):
        game = await self.start()
        await self.flow.stats(self.command("/stata"))
        text = self.bot.call_args.args[0].text
        self.assertIn("5 карт", text)
        self.assertIn("0/10", text)
        self.assertTrue(all(card not in text for hand in game.hands.values() for card in hand))

    async def test_failed_next_turn_announcement_retries_without_second_card_transfer(self):
        game = await self.start()
        turn = await self.ephemeral_move(game)
        self.public.accept_vote(turn, 102, "P2", False, "yes")

        async def fail_next_panel(**kwargs):
            if "· Ход 2/" in kwargs["rich_message"].blocks[0].text.text:
                raise TelegramNetworkError(method=SendMessage(chat_id=game.chat_id, text="test"), message="offline")
            return await self.sent(**kwargs)

        self.bot.send_rich_message.side_effect = fail_next_panel
        with self.assertRaises(TelegramNetworkError):
            await self.public.resume(self.bot, turn)
        self.assertTrue(turn.match_applied)
        self.assertFalse(turn.announcement_done)
        self.assertEqual(game.turns_done, 1)
        self.assertNotIn(1, game.announcements)
        self.bot.send_rich_message.side_effect = self.sent
        await self.public.resume(self.bot, turn)
        self.assertIn(1, game.announcements)
        self.assertEqual(game.turns_done, 1)
        self.assertEqual(sum(map(len, game.hands.values())), 10)

    async def ephemeral_move(self, game):
        actor = game.author.user_id
        await lab.open_hand(self.normal_callback(f"lab3:game:{game.token}:{game.turns_done}", actor,
                                                 game.announcements[game.turns_done]), self.bot)
        for action, value in (("select", 0), ("claim", DECK.index(game.hands[actor][0])), ("confirm", None)):
            view = lab.views[(game.chat_id, actor)]
            data = f"lab3:{action}:{view.nonce}:{view.revision}" + (f":{value}" if value is not None else "")
            await lab.update_selection(self.normal_callback(data, actor, ephemeral_id=view.ephemeral_id), self.bot)
        return self.public.turns[lab.views[(game.chat_id, actor)].public_turn_id]

    def shared_settings(self):
        directory = TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        store = GroupSettings(Path(directory.name) / "settings.json")
        self.flow.modes = store.get
        return store

    async def test_disabled_inline_is_hidden_and_rejects_existing_draft(self):
        store = self.shared_settings()
        game = await self.start()
        proposal, session = self.draft(game)
        store.set_mode(game.chat_id, "inline", False, 0)
        await self.flow.refresh_modes(self.bot, game.chat_id)
        labels = [row[0].text for row in self.bot.edit_message_reply_markup.call_args.kwargs["reply_markup"].inline_keyboard]
        self.assertEqual(labels, ["Мои карты"])
        self.assertEqual(session.phase, "cancelled")
        await self.inline.on_callback(self.inline_callback(f"lab4:confirm:{proposal.token}", 101, "old-draft"), self.bot)
        self.assertIsNone(game.pending)
        panel = session.panel
        query_ = InlineQuery(id="query", from_user=User(id=101, is_bot=False, first_name="Tester"),
                             query=f"lab4 {panel.token} 1", offset="", chat_type="supergroup")
        self.assertEqual(self.inline.build_results(query_), [])

    async def test_ephemeral_only_turn_has_no_inline_hint_and_disabled_ephemeral_cannot_open(self):
        store = self.shared_settings()
        store.set_mode(-100123, "inline", False, 0)
        with patch.object(self.inline, "prepare_faces", new_callable=AsyncMock) as prepare:
            game = await self.start()
            prepare.assert_not_awaited()
        self.assertFalse(any(block.type == "details" for block in self.bot.send_rich_message.call_args.kwargs["rich_message"].blocks))
        store.set_mode(game.chat_id, "inline", True, 1)
        store.set_mode(game.chat_id, "ephemeral", False, 2)
        self.bot.send_message.reset_mock()
        await lab.open_hand(self.normal_callback(f"lab3:game:{game.token}:0", message_id=game.announcements[0]), self.bot)
        self.assertNotIn((game.chat_id, 101), lab.views)
        self.bot.send_message.assert_not_awaited()

    async def test_settings_change_does_not_cancel_committed_move(self):
        store = self.shared_settings()
        game = await self.start()
        turn = await self.ephemeral_move(game)
        store.set_mode(game.chat_id, "ephemeral", False, 0)
        await self.flow.refresh_modes(self.bot, game.chat_id)
        self.assertEqual(game.pending.token, turn.token)
        await self.vote(turn, game.voter.user_id)
        self.assertEqual(game.turns_done, 1)
        self.assertEqual(sum(map(len, game.hands.values())), 10)

    async def test_personal_buttons_follow_current_author_and_group_limits(self):
        store = self.shared_settings()
        self.flow.player_modes = store.effective
        store.set_personal(101, "inline", 0)
        store.set_personal(102, "ephemeral", 0)
        game = await self.start()
        labels = [row[0].text for row in self.bot.send_rich_message.call_args.kwargs["reply_markup"].inline_keyboard]
        self.assertEqual(labels, ["Скинуть карту"])
        await self.flow.show_mode(self.bot, game, 101, "inline")
        self.assertEqual([row[0].text for row in self.bot.edit_message_reply_markup.call_args.kwargs["reply_markup"].inline_keyboard],
                         ["Скинуть карту"])
        await lab.open_hand(self.normal_callback(f"lab3:game:{game.token}:0", message_id=game.announcements[0]), self.bot)
        self.assertNotIn((game.chat_id, 101), lab.views)
        turn = await self.inline_move(game)
        await self.vote(turn, 102)
        panel = self.bot.send_rich_message.call_args.kwargs
        self.assertEqual([row[0].text for row in panel["reply_markup"].inline_keyboard], ["Мои карты"])
        self.assertFalse(any(block.type == "details" for block in panel["rich_message"].blocks))

    async def test_final_score_separates_single_winner_and_preserves_global_numbering(self):
        game = await self.start()
        for index in range(10):
            author = game.author.user_id
            turn = await (self.inline_move(game) if index % 2 else self.ephemeral_move(game))
            await self.vote(turn, game.voter.user_id, "yes" if author == 101 else "no")
        final = self.bot.send_message.call_args.kwargs
        self.assertTrue(final["text"].startswith("🏆 <b>Партия завершена!</b>\n\nХодов сыграно: 10/10"))
        self.assertIn('<b>Победитель:</b>\n1. <a href="tg://user?id=102">P2</a> — 0 карт', final["text"])
        self.assertIn('<b>Остальные игроки:</b>\n2. <a href="tg://user?id=101">Author</a> — 10 карт', final["text"])
        self.assertTrue(final["text"].endswith("Новая партия: /game."))

    async def test_inline_vote_recovery_rejects_third_player_before_reserving_card(self):
        game = await self.start(3)
        proposal, session = self.draft(game)
        data = f"lab4:vote:{proposal.token}:yes"
        await self.inline.on_callback(self.inline_callback(data, 103, "selected-message"), self.bot)
        self.assertIsNone(game.pending)
        self.assertEqual(session.phase, "choosing")
        self.bot.send_sticker.assert_not_awaited()
        await self.inline.on_callback(self.inline_callback(data, 102, "selected-message"), self.bot)
        self.assertEqual(game.turns_done, 1)
        self.assertTrue(self.public.turns[session.public_turn_id].finished)

    async def inline_move(self, game):
        panel = next(panel for panel in self.inline.panels.values()
                     if panel.match_id == game.token and panel.match_turn == game.turns_done)
        query_ = InlineQuery(id="inline-query", from_user=User(id=game.author.user_id, is_bot=False, first_name="Tester"),
                             query=f"lab4 {panel.token} 1", offset="", chat_type="supergroup")
        results = self.inline.build_results(query_)
        result = results[DECK.index(game.hands[game.author.user_id][0])]
        self.last_inline_content = result.input_message_content
        proposal, session = self.inline.get_proposal(result.id, game.author.user_id)
        chosen = ChosenInlineResult(result_id=proposal.token, from_user=query_.from_user,
                                   query=query_.query, inline_message_id=f"inline-turn-{game.turns_done}")
        await self.inline.on_chosen(chosen, self.bot)
        return self.public.turns[session.public_turn_id]

    async def vote(self, turn, voter_id, answer="yes"):
        data = f"lab3:vote:{turn.token}:{answer}"
        callback = (self.inline_callback(data, voter_id, turn.inline_claim_id) if turn.inline_claim_id else
                    self.normal_callback(data, voter_id, turn.claim_id))
        await lab.vote_public(callback, self.bot)

    async def test_full_ten_turn_party_alternates_both_interfaces_and_announces_winner_once(self):
        game = await self.start()
        for index in range(10):
            author, voter = game.author.user_id, game.voter.user_id
            turn = await (self.ephemeral_move(game) if index % 2 == 0 else self.inline_move(game))
            self.assertEqual(sum(map(len, game.hands.values())), 9)
            self.assertEqual(turn.expected_voter_id, voter)
            self.assertIn("Отвечает:", self.last_inline_content.message_text if turn.inline_claim_id
                          else self.bot.send_message.call_args.kwargs["text"])
            published = ({"text": self.last_inline_content.message_text, "parse_mode": self.last_inline_content.parse_mode} if turn.inline_claim_id
                         else self.bot.send_message.call_args.kwargs)
            self.assertEqual(published["parse_mode"], "HTML")
            self.assertTrue(published["text"].endswith(
                f'<a href="tg://user?id={voter}">{turn.expected_voter_name}</a>, веришь?'))
            await self.vote(turn, author)
            self.assertIsNone(turn.vote)
            await self.vote(turn, voter)
            self.assertTrue(turn.match_applied)
            self.assertEqual(game.turns_done, index + 1)
            self.assertEqual(sum(map(len, game.hands.values())), 10)
            if index < 9:
                self.assertIn(index + 1, game.announcements)
                self.assertEqual(self.bot.send_rich_message.call_args.kwargs["rich_message"].blocks[1].text[1].user.id,
                                 game.author.user_id)
        self.assertEqual(game.status, "finished")
        self.assertIsNotNone(game.final_message_id)
        self.assertIn("ничья", self.bot.send_message.call_args.kwargs["text"])
        count = self.bot.send_message.await_count
        await self.public.resume(self.bot, turn)
        self.assertEqual(self.bot.send_message.await_count, count)
        self.assertEqual(game.turns_done, 10)

    async def test_back_is_absent_from_single_mode_group_panel_and_ephemeral_window(self):
        store = self.shared_settings()
        store.set_mode(-100123, "inline", False, 0)
        game = await self.start()
        await lab.open_hand(self.normal_callback(f"lab3:game:{game.token}:0", message_id=game.announcements[0]), self.bot)
        view = lab.views[(game.chat_id, 101)]
        self.assertFalse(any(button.text == "Назад к выбору режима"
                             for row in lab.hand_keyboard(view).inline_keyboard for button in row))
        keyboard = self.bot.edit_message_reply_markup.call_args.kwargs["reply_markup"]
        self.assertEqual([row[0].text for row in keyboard.inline_keyboard], ["Мои карты"])

    async def test_wrong_author_and_third_player_cannot_bypass_schedule(self):
        game = await self.start(3)
        await lab.open_hand(self.normal_callback(f"lab3:game:{game.token}:0", 102, game.announcements[0]), self.bot)
        self.assertNotIn((game.chat_id, 102), lab.views)
        turn = await self.ephemeral_move(game)
        await self.vote(turn, 103)
        self.assertIsNone(turn.vote)
        await self.vote(turn, 102)
        self.assertEqual(game.turns_done, 1)

    async def test_standalone_drafts_and_old_turn_buttons_do_not_bypass_party(self):
        game = await self.start()
        real = game.hands[101][0]
        with self.assertRaises(PublicTurnError):
            self.public.create_turn(game.chat_id, None, 101, "Author", ConfirmedMove(real, real, True))
        turn = await self.ephemeral_move(game)
        await self.vote(turn, 102)
        with self.assertRaises(PublicTurnError):
            self.public.create_turn(game.chat_id, None, 101, "Author", ConfirmedMove(real, real, True),
                                     match_id=game.token, match_turn=0)

    async def test_missing_public_result_can_retry_without_changing_hands_twice(self):
        game = await self.start()
        turn = await self.ephemeral_move(game)
        self.public.accept_vote(turn, 102, "P2", False, "yes")
        self.bot.send_message.side_effect = TelegramNetworkError(
            method=SendMessage(chat_id=game.chat_id, text="test"), message="offline")
        with self.assertRaises(TelegramNetworkError):
            await self.public.resume(self.bot, turn)
        self.assertEqual(game.turns_done, 0)
        self.assertEqual(sum(map(len, game.hands.values())), 9)
        self.bot.send_message.side_effect = self.sent
        await self.public.resume(self.bot, turn)
        await self.public.resume(self.bot, turn)
        self.assertEqual(game.turns_done, 1)
        self.assertEqual(sum(map(len, game.hands.values())), 10)

    async def test_stop_invalidates_pending_moves_and_new_party_gets_new_identity(self):
        game = await self.start()
        turn = await self.ephemeral_move(game)
        self.matches.stop(game)
        with self.assertRaises(PublicTurnError):
            await self.public.resume(self.bot, turn)
        with self.assertRaises(PublicTurnError):
            self.public.accept_vote(turn, 102, "P2", False, "yes")
        newer = self.matches.create(game.chat_id, None, 101, "Author")
        self.assertNotEqual(newer.token, game.token)

    async def test_growing_inline_hand_can_select_more_than_five_cards(self):
        game = await self.start()
        used = set(card for hand in game.hands.values() for card in hand)
        game.hands[101].append(next(card for card in DECK if card not in used))
        panel = next(iter(self.inline.panels.values()))
        incoming = InlineQuery(id="q", from_user=User(id=101, is_bot=False, first_name="Author"),
                               query=f"lab4 {panel.token} 6", offset="", chat_type="supergroup")
        results = self.inline.build_results(incoming)
        self.assertEqual(len(results), 36)
        self.assertIn(game.hands[101][5], results[0].title)

    async def test_face_grid_selects_real_card_visually_and_keeps_party_schedule(self):
        game = await self.start()
        panel = next(iter(self.inline.panels.values()))
        incoming = InlineQuery(id="faces", from_user=User(id=101, is_bot=False, first_name="Author"),
                               query=f"lab4 {panel.token} =6пик", offset="", chat_type="supergroup")
        results = self.inline.build_results(incoming)
        self.assertEqual(len(results), 5)
        index = next(i for i, card in enumerate(game.hands[101]) if card != "6 ♠")
        selected = results[index]
        real = game.hands[101][index]
        self.assertEqual(selected.sticker_file_id, self.inline.faces.ids[real])
        self.assertNotIn(real, selected.input_message_content.message_text)
        proposal, session = self.inline.get_proposal(selected.id, 101)
        await self.inline.on_callback(self.inline_callback(f"lab4:confirm:{proposal.token}", 101, "face-turn"), self.bot)
        turn = self.public.turns[session.public_turn_id]
        self.assertEqual(turn.move.real_card, real)
        self.assertEqual(turn.move.declared_card, "6 ♠")
        await self.vote(turn, 102, "no")
        self.assertEqual(game.turns_done, 1)
        self.assertEqual(game.author.user_id, 102)


if __name__ == "__main__":
    unittest.main()
