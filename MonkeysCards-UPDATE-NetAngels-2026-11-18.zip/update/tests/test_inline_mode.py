"""Only final inline statements reach the group; validate the bound chat and owner."""

from pathlib import Path
from datetime import datetime, timezone
from types import SimpleNamespace
import unittest
from unittest.mock import AsyncMock, patch

from aiogram.exceptions import TelegramBadRequest, TelegramNetworkError
from aiogram.methods import SendMessage
from aiogram.types import CallbackQuery, Chat, ChosenInlineResult, InlineQuery, Message, User

import main as lab
from card_selection import DECK
from inline_mode import INLINE_TTL, InlineLab, InlinePanel
from public_turn import PublicLab
from test_experiment import query

HAND = (DECK[0], DECK[8], DECK[9], DECK[17], DECK[35])


class InlineFlowTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.public = PublicLab(Path("offline-test-assets"))
        self.flow = InlineLab(lambda: self.public, lambda chat, user: HAND)
        self.flow.faces.ids = {card: f"offline-face-{index}" for index, card in enumerate(DECK)}
        self.panel = InlinePanel("offline-panel", -100123, 777, message_id=42,
                                 chat_instance="offline-group")
        self.flow.panels[self.panel.token] = self.panel
        self.bot = AsyncMock()
        self.bot.id = 777
        self.next_id = 100
        self.bot.send_message.side_effect = self.sent
        self.bot.send_sticker.side_effect = self.sent

    async def sent(self, **kwargs):
        self.next_id += 1
        return SimpleNamespace(message_id=self.next_id, sticker=SimpleNamespace(file_id=f"offline-{self.next_id}"))

    def inline_query(self, text=None, user_id=101, chat_type="supergroup"):
        return InlineQuery(id="offline-query", from_user=User(id=user_id, is_bot=False, first_name="Tester"),
                           query=text or f"lab4 {self.panel.token}", offset="", chat_type=chat_type).as_(self.bot)

    def candidates(self, number="1"):
        return self.flow.build_results(self.inline_query(f"lab4 {self.panel.token} {number}"))

    def draft(self, claimed_index=9, number="1"):
        return self.flow.get_proposal(self.candidates(number)[claimed_index].id, 101)

    def callback(self, token, action="confirm", user_id=101,
                 chat_instance="offline-group", inline_id="offline-inline-message"):
        return CallbackQuery(id="offline-callback",
                             from_user=User(id=user_id, is_bot=False, first_name="Tester"),
                             chat_instance=chat_instance, inline_message_id=inline_id,
                             data=f"lab4:{action}:{token}").as_(self.bot)

    def error(self, kind=TelegramNetworkError, message="offline"):
        return kind(method=SendMessage(chat_id=-100123, text="test"), message=message)

    async def test_preview_shows_hand_but_every_selectable_item_is_final_claim(self):
        results = self.candidates()
        self.assertEqual(len(results), 36)
        for index, result in enumerate(results):
            for position, card in enumerate(HAND):
                self.assertIn(f"{position + 1}:{card.replace(' ', '')}", result.description)
            self.assertIn(HAND[0], result.title)
            self.assertIn(DECK[index], result.input_message_content.message_text)
            self.assertNotIn("Настоящая карта выбрана", result.input_message_content.message_text)
            buttons = [b for row in result.reply_markup.inline_keyboard for b in row]
            self.assertEqual([b.text for b in buttons], ["Верю", "Не верю"])
            self.assertTrue(all(b.switch_inline_query_current_chat is None for b in buttons))
        self.bot.send_message.assert_not_awaited()

    async def test_all_five_real_cards_and_36_claims_are_selectable_without_posts(self):
        for number in range(1, 6):
            results = self.candidates(str(number))
            self.assertEqual(len(results), 36)
            for index, result in enumerate(results):
                proposal, _ = self.flow.get_proposal(result.id, 101)
                self.assertEqual(proposal.real_index, number - 1)
                self.assertEqual(proposal.declared_index, index)
                self.assertIn(f"Играю {HAND[number - 1]}", result.title)
                self.assertLessEqual(len(result.id.encode()), 64)
                for row in result.reply_markup.inline_keyboard:
                    self.assertTrue(all(len(b.callback_data.encode()) <= 64 for b in row))
        self.bot.send_message.assert_not_awaited()
        self.bot.send_sticker.assert_not_awaited()

    async def test_missing_number_defaults_to_first_card_and_invalid_numbers_return_nothing(self):
        results = self.flow.build_results(self.inline_query())
        self.assertEqual(len(results), 5)
        self.assertEqual(self.flow.get_proposal(results[0].id, 101)[0].real_index, 0)
        for number in ("0", "6", "-1", "01", "claim", "1 2", "１"):
            with self.subTest(number=number):
                self.assertEqual(self.candidates(number), [])

    async def test_answer_is_personal_and_not_cached(self):
        await self.flow.answer_query(self.inline_query())
        method = self.bot.call_args.args[0]
        self.assertEqual(method.__api_method__, "answerInlineQuery")
        self.assertEqual(method.cache_time, 0)
        self.assertTrue(method.is_personal)
        self.assertEqual(len(method.results), 5)

    async def test_group_must_be_bound_by_normal_callback_before_showing_cards(self):
        self.panel.chat_instance = None
        self.assertEqual(self.flow.build_results(self.inline_query()), [])
        await self.flow.on_callback(query(data=f"lab4:enable:{self.panel.token}").as_(self.bot), self.bot)
        self.assertEqual(self.panel.chat_instance, "offline-group")
        self.assertEqual(len(self.flow.build_results(self.inline_query())), 5)
        self.bot.send_message.assert_not_awaited()
        self.assertEqual(self.bot.edit_message_reply_markup.call_args.kwargs["message_id"], 42)

    async def test_other_group_cannot_bind_the_panel(self):
        self.panel.chat_instance = None
        enable = query(chat_id=-100456, data=f"lab4:enable:{self.panel.token}").as_(self.bot)
        await self.flow.on_callback(enable, self.bot)
        self.assertIsNone(self.panel.chat_instance)

    async def test_private_channel_and_unknown_chat_types_have_no_cards(self):
        for chat_type in ("private", "sender", "channel", None):
            with self.subTest(chat_type=chat_type):
                self.assertEqual(self.flow.build_results(self.inline_query(chat_type=chat_type)), [])

    async def test_missing_feedback_confirmation_reuses_claim_and_posts_no_extra_text(self):
        proposal, session = self.draft()
        self.assertFalse(proposal.feedback_seen)
        await self.flow.on_callback(self.callback(proposal.token), self.bot)
        turn = self.public.turns[session.public_turn_id]
        self.assertEqual(session.phase, "confirmed")
        self.assertEqual(turn.move.real_card, HAND[0])
        self.assertEqual(turn.move.declared_card, DECK[9])
        self.assertEqual(turn.inline_claim_id, "offline-inline-message")
        self.assertIsNone(turn.claim_id)
        self.assertTrue(turn.inline_vote_ready)
        self.assertIn("Ожидается ответ", self.public.status_text(turn.token))
        self.bot.send_message.assert_not_awaited()
        self.bot.edit_ephemeral_message_text.assert_not_awaited()
        self.assertEqual(self.bot.send_sticker.await_count, 1)
        edit = self.bot.edit_message_text.call_args.kwargs
        self.assertEqual(edit["inline_message_id"], "offline-inline-message")
        self.assertEqual(edit["parse_mode"], "HTML")
        self.assertNotIn(HAND[0], edit["text"])
        self.assertEqual([b.text for b in edit["reply_markup"].inline_keyboard[0]], ["Верю", "Не верю"])

    async def test_feedback_without_inline_message_reference_cannot_commit(self):
        proposal, session = self.draft()
        chosen = ChosenInlineResult(result_id=proposal.token,
                                    from_user=User(id=101, is_bot=False, first_name="Tester"), query="opaque")
        await self.flow.on_chosen(chosen)
        self.assertTrue(proposal.feedback_seen)
        self.assertEqual(session.phase, "choosing")
        self.assertEqual(len(self.public.turns), 0)
        self.bot.send_message.assert_not_awaited()

    async def test_confirmation_requires_owner_and_original_chat_instance(self):
        proposal, session = self.draft()
        for kwargs in ({"user_id": 202}, {"chat_instance": "another-group"}):
            with self.subTest(kwargs=kwargs):
                await self.flow.on_callback(self.callback(proposal.token, **kwargs), self.bot)
        await self.flow.on_callback(query(data=f"lab4:confirm:{proposal.token}").as_(self.bot), self.bot)
        self.assertEqual(session.phase, "choosing")
        self.assertEqual(len(self.public.turns), 0)
        self.bot.send_message.assert_not_awaited()

    async def test_duplicate_confirmation_does_not_publish_twice(self):
        proposal, session = self.draft()
        callback = self.callback(proposal.token)
        await self.flow.on_callback(callback, self.bot)
        await self.flow.on_callback(callback, self.bot)
        self.assertEqual(len(self.public.turns), 1)
        self.assertEqual(self.bot.send_sticker.await_count, 1)
        self.assertEqual(self.bot.edit_message_text.await_count, 1)
        self.bot.send_message.assert_not_awaited()

    async def test_other_inline_message_and_candidate_cannot_replace_committed_choice(self):
        candidates = self.candidates()
        proposal, session = self.flow.get_proposal(candidates[9].id, 101)
        await self.flow.on_callback(self.callback(proposal.token), self.bot)
        await self.flow.on_callback(self.callback(proposal.token, inline_id="copied-message"), self.bot)
        await self.flow.on_callback(self.callback(candidates[10].id), self.bot)
        self.assertEqual(session.active_candidate, proposal.token)
        self.assertEqual(len(self.public.turns), 1)
        self.assertEqual(self.bot.send_sticker.await_count, 1)

    async def test_cancel_edits_same_statement_and_invalidates_old_buttons(self):
        proposal, session = self.draft()
        await self.flow.on_callback(self.callback(proposal.token, "cancel"), self.bot)
        await self.flow.on_callback(self.callback(proposal.token), self.bot)
        self.assertEqual(session.phase, "cancelled")
        self.assertEqual(len(self.public.turns), 0)
        self.bot.send_message.assert_not_awaited()
        self.assertEqual(self.bot.edit_message_text.call_args.kwargs["inline_message_id"], "offline-inline-message")
        self.assertEqual(self.bot.edit_message_text.call_args.kwargs["text"], "Выбор отменен.")
        self.assertEqual(len(self.candidates()), 36)

    async def test_network_failure_after_commit_keeps_choice_and_allows_resume(self):
        proposal, session = self.draft()
        self.bot.send_sticker.side_effect = self.error()
        await self.flow.on_callback(self.callback(proposal.token), self.bot)
        self.assertEqual(session.phase, "confirmed")
        self.assertTrue(self.public.turns[session.public_turn_id].delivery_failed)
        self.bot.send_sticker.side_effect = self.sent
        await self.flow.on_callback(self.callback(proposal.token, "status"), self.bot)
        self.assertEqual(len(self.public.turns), 1)
        self.assertTrue(self.public.turns[session.public_turn_id].inline_vote_ready)
        self.bot.send_message.assert_not_awaited()

    async def test_failed_cancel_can_retry_removing_card_from_statement(self):
        proposal, session = self.draft()
        self.bot.edit_message_text.side_effect = self.error()
        await self.flow.on_callback(self.callback(proposal.token, "cancel"), self.bot)
        self.assertEqual(session.phase, "choosing")
        self.bot.edit_message_text.side_effect = None
        await self.flow.on_callback(self.callback(proposal.token, "cancel"), self.bot)
        self.assertEqual(session.phase, "cancelled")
        self.assertEqual(self.bot.edit_message_text.call_args.kwargs["text"], "Выбор отменен.")
        self.assertEqual(len(self.public.turns), 0)

    async def test_failed_inline_edit_does_not_resend_back_when_retried(self):
        proposal, session = self.draft()
        self.bot.edit_message_text.side_effect = self.error()
        await self.flow.on_callback(self.callback(proposal.token), self.bot)
        self.assertFalse(self.public.turns[session.public_turn_id].inline_vote_ready)
        self.bot.edit_message_text.side_effect = None
        await self.flow.on_callback(self.callback(proposal.token, "status"), self.bot)
        self.assertTrue(self.public.turns[session.public_turn_id].inline_vote_ready)
        self.assertEqual(self.bot.send_sticker.await_count, 1)
        self.bot.send_message.assert_not_awaited()

    async def test_not_modified_retry_is_treated_as_already_applied_edit(self):
        proposal, session = self.draft()
        self.bot.edit_message_text.side_effect = self.error(TelegramBadRequest, "Bad Request: message is not modified")
        await self.flow.on_callback(self.callback(proposal.token), self.bot)
        self.assertTrue(self.public.turns[session.public_turn_id].inline_vote_ready)
        self.assertFalse(self.public.turns[session.public_turn_id].delivery_failed)

    async def test_other_bad_request_is_not_ignored(self):
        proposal, session = self.draft()
        self.bot.edit_message_text.side_effect = self.error(TelegramBadRequest, "Bad Request: message to edit not found")
        await self.flow.on_callback(self.callback(proposal.token), self.bot)
        self.assertFalse(self.public.turns[session.public_turn_id].inline_vote_ready)
        self.assertTrue(self.public.turns[session.public_turn_id].delivery_failed)

    async def test_expired_and_restart_data_cannot_publish(self):
        proposal, session = self.draft()
        session.created_at -= INLINE_TTL + 1
        await self.flow.on_callback(self.callback(proposal.token), self.bot)
        self.flow.clear()
        await self.flow.on_callback(self.callback(proposal.token), self.bot)
        self.assertEqual(len(self.public.turns), 0)

    async def test_feedback_after_confirmation_does_not_duplicate_turn(self):
        proposal, session = self.draft()
        await self.flow.on_callback(self.callback(proposal.token), self.bot)
        chosen = ChosenInlineResult(result_id=proposal.token,
                                    from_user=User(id=101, is_bot=False, first_name="Tester"), query="opaque")
        await self.flow.on_chosen(chosen)
        self.assertTrue(proposal.feedback_seen)
        self.assertEqual(session.phase, "confirmed")
        self.assertEqual(len(self.public.turns), 1)

    async def test_full_cycle_checks_inline_votes_and_only_adds_final_sticker_and_result(self):
        proposal, session = self.draft()
        await self.flow.on_callback(self.callback(proposal.token), self.bot)
        turn = self.public.turns[session.public_turn_id]
        vote = self.callback(proposal.token, user_id=202).model_copy(
            update={"data": f"lab3:vote:{turn.token}:no"})
        with patch.object(lab, "public_lab", self.public):
            await lab.vote_public(vote.model_copy(update={"chat_instance": "another-group"}), self.bot)
            await lab.vote_public(vote.model_copy(update={"inline_message_id": "another-message"}), self.bot)
            self.assertIsNone(turn.vote)
            await lab.vote_public(vote, self.bot)
            await lab.vote_public(vote, self.bot)
        self.assertTrue(turn.finished)
        self.assertEqual(turn.outcome.receiver_id, 101)
        self.assertEqual(self.bot.send_sticker.await_count, 2)
        self.assertEqual(self.bot.send_message.await_count, 1)
        self.assertIn("Карта осталась у", self.bot.send_message.call_args.kwargs["text"])
        await self.flow.on_callback(self.callback(proposal.token, "new"), self.bot)
        self.assertEqual(session.phase, "cancelled")
        self.assertEqual(len(self.candidates()), 36)

    async def test_reset_cannot_cancel_other_players_or_unfinished_public_turn(self):
        proposal, session = self.draft()
        await self.flow.on_callback(self.callback(proposal.token), self.bot)
        for user_id in (202, 101):
            await self.flow.on_callback(query(user_id=user_id, data=f"lab4:reset:{self.panel.token}").as_(self.bot), self.bot)
            self.assertEqual(session.phase, "confirmed")
        await self.flow.on_callback(self.callback(proposal.token, "new"), self.bot)
        self.assertEqual(session.phase, "confirmed")

    def chosen(self, proposal, user_id=101, inline_id="offline-inline-message", query_text=None):
        return ChosenInlineResult(result_id=proposal.token,
            from_user=User(id=user_id, is_bot=False, first_name="Tester"),
            query=query_text or f"lab4 {self.panel.token} 1", inline_message_id=inline_id)

    def group_message(self, proposal, chat_id=-100123, user_id=101, via_bot=777, message_id=900):
        return Message(message_id=message_id, date=datetime.now(timezone.utc),
            chat=Chat(id=chat_id, type="supergroup"), message_thread_id=777,
            from_user=User(id=user_id, is_bot=False, first_name="Tester"),
            via_bot=User(id=via_bot, is_bot=True, first_name="LAB"),
            reply_markup=self.flow.selection_keyboard(proposal.token), text="Selected claim").as_(self.bot)

    async def test_group_message_sends_back_before_vote_without_feedback_and_avoids_duplicates(self):
        proposal, session = self.draft()
        message = self.group_message(proposal)
        await self.flow.on_group_choice(message, self.bot)
        turn = self.public.turns[session.public_turn_id]
        self.assertEqual(turn.claim_id, 900)
        self.assertIsNotNone(turn.back_id)
        self.assertIsNone(turn.vote)
        self.assertIsNone(turn.face_id)
        self.assertEqual(self.bot.send_sticker.await_count, 1)
        self.bot.send_message.assert_not_awaited()
        await self.flow.on_group_choice(message, self.bot)
        self.assertEqual(self.bot.send_sticker.await_count, 1)
        vote = self.callback(proposal.token, user_id=202).model_copy(update={"data": f"lab4:vote:{proposal.token}:no"})
        await self.flow.on_callback(vote, self.bot)
        self.assertTrue(turn.finished)
        self.assertEqual(self.bot.send_sticker.await_count, 2)
        await self.flow.on_chosen(self.chosen(proposal), self.bot)
        self.assertEqual(self.bot.send_sticker.await_count, 2)

    async def test_group_message_rejects_another_group_author_and_inline_bot(self):
        proposal, session = self.draft()
        for message in (self.group_message(proposal, chat_id=-100456),
                        self.group_message(proposal, user_id=202), self.group_message(proposal, via_bot=778)):
            await self.flow.on_group_choice(message, self.bot)
        self.assertEqual(session.phase, "choosing")
        self.bot.send_sticker.assert_not_awaited()
        self.assertEqual(len(self.public.turns), 0)

    async def test_feedback_first_then_group_message_keeps_one_back_and_checks_message_identity(self):
        proposal, session = self.draft()
        await self.flow.on_chosen(self.chosen(proposal), self.bot)
        await self.flow.on_group_choice(self.group_message(proposal), self.bot)
        await self.flow.on_group_choice(self.group_message(proposal, message_id=901), self.bot)
        turn = self.public.turns[session.public_turn_id]
        self.assertEqual(turn.claim_id, 900)
        self.assertTrue(turn.inline_origin_verified)
        self.assertEqual(self.bot.send_sticker.await_count, 1)

    async def test_selection_feedback_commits_without_author_confirmation_or_extra_posts(self):
        result = self.candidates()[9]
        self.assertEqual([button.text for row in result.reply_markup.inline_keyboard for button in row],
                         ["Верю", "Не верю"])
        self.assertNotIn("Подтвердите", result.input_message_content.message_text)
        proposal, session = self.flow.get_proposal(result.id, 101)
        await self.flow.on_chosen(self.chosen(proposal), self.bot)
        await self.flow.on_chosen(self.chosen(proposal), self.bot)
        self.assertEqual(session.phase, "confirmed")
        self.assertEqual(len(self.public.turns), 1)
        self.assertEqual(self.bot.send_sticker.await_count, 1)
        self.bot.send_message.assert_not_awaited()
        self.bot.edit_message_text.assert_not_awaited()

    async def test_selection_feedback_rejects_wrong_author_query_and_replacement_message(self):
        proposal, session = self.draft()
        await self.flow.on_chosen(self.chosen(proposal, user_id=202), self.bot)
        await self.flow.on_chosen(self.chosen(proposal, query_text="lab4 another-panel 1"), self.bot)
        self.assertEqual(session.phase, "choosing")
        await self.flow.on_chosen(self.chosen(proposal), self.bot)
        await self.flow.on_chosen(self.chosen(proposal, inline_id="another-message"), self.bot)
        self.assertEqual(proposal.inline_message_id, "offline-inline-message")
        self.assertEqual(len(self.public.turns), 1)

    async def test_vote_recovers_missing_feedback_without_confirmation_and_checks_source(self):
        proposal, session = self.draft()
        vote = self.callback(proposal.token, user_id=202).model_copy(update={"data": f"lab4:vote:{proposal.token}:no"})
        await self.flow.on_callback(vote.model_copy(update={"chat_instance": "another-group"}), self.bot)
        self.assertEqual(session.phase, "choosing")
        await self.flow.on_callback(self.callback(proposal.token).model_copy(update={"data": vote.data}), self.bot)
        self.assertEqual(session.phase, "choosing")
        await self.flow.on_callback(vote, self.bot)
        turn = self.public.turns[session.public_turn_id]
        self.assertTrue(turn.finished)
        self.assertEqual(turn.outcome.receiver_id, 101)
        self.assertEqual(self.bot.send_sticker.await_count, 2)
        self.assertEqual(self.bot.send_message.await_count, 1)
        await self.flow.on_chosen(self.chosen(proposal), self.bot)
        self.assertEqual(self.bot.send_sticker.await_count, 2)

    async def test_automatic_choice_network_failure_can_resume_from_vote_without_second_commit(self):
        proposal, session = self.draft()
        self.bot.send_sticker.side_effect = self.error()
        await self.flow.on_chosen(self.chosen(proposal), self.bot)
        turn = self.public.turns[session.public_turn_id]
        self.assertTrue(turn.delivery_failed)
        self.assertEqual(session.phase, "confirmed")
        self.bot.edit_message_reply_markup.assert_not_awaited()
        self.bot.send_sticker.side_effect = self.sent
        vote = self.callback(proposal.token, user_id=202).model_copy(update={"data": f"lab4:vote:{proposal.token}:yes"})
        await self.flow.on_callback(vote, self.bot)
        self.assertTrue(turn.finished)
        self.assertEqual(len(self.public.turns), 1)
        self.assertEqual(turn.outcome.receiver_id, 202)
        await self.flow.on_chosen(self.chosen(proposal), self.bot)
        self.assertEqual(self.bot.send_sticker.await_count, 3)  # one failed upload, back, face


if __name__ == "__main__":
    unittest.main()
