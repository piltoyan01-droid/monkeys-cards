"""Public experiment: privacy before voting, four outcomes, delivery and retries."""

import asyncio
from pathlib import Path
from html.parser import HTMLParser
from types import SimpleNamespace
import unittest
from unittest.mock import AsyncMock, patch

from aiogram.exceptions import TelegramNetworkError
from aiogram.methods import SendMessage
from aiogram.types import User

import main as lab
from card_selection import ConfirmedMove, DECK, Phase
from public_turn import (
    PublicLab, PublicTurn, PublicTurnError, TURN_TTL, card_filename, claim_text, result_text, resolve_vote,
    KNOWN_PROFILES, profile_link, remember_profile, rich_profile,
)
from test_experiment import query


class PublicRuleTests(unittest.TestCase):
    def test_profile_links_use_known_username_and_explicit_rich_user_identity(self):
        with patch.dict(KNOWN_PROFILES, {}, clear=True):
            remember_profile(User(id=101, is_bot=False, first_name="Валерия", username="lab_valeria"))
            self.assertEqual(profile_link(101, "Валерия & V"),
                             '<a href="https://t.me/lab_valeria">Валерия &amp; V</a>')
            mention = rich_profile(101, "Валерия & V")
            self.assertEqual(mention.type, "text_mention")
            self.assertEqual(mention.user.id, 101)
            self.assertEqual(mention.text, "Валерия & V")
            self.assertIn('tg://user?id=202', profile_link(202, "leru"))

    def test_all_four_vote_outcomes(self):
        for truthful, vote, guessed in ((True, "yes", True), (True, "no", False),
                                        (False, "yes", False), (False, "no", True)):
            with self.subTest(truthful=truthful, vote=vote):
                move = ConfirmedMove("6 ♠", "6 ♠" if truthful else "6 ♥", truthful)
                outcome = resolve_vote(move, vote, 101, "Author", 202, "Voter")
                self.assertEqual(outcome.guessed, guessed)
                self.assertEqual(outcome.receiver_id, 101 if guessed else 202)
                turn = PublicTurn("test", -100123, None, 101, "Author", move,
                                  voter_id=202, voter_name="Voter", vote=vote,
                                  match_id="party", expected_voter_id=202, expected_voter_name="Voter")
                text = result_text(turn)
                receiver = "Author" if guessed else "Voter"
                if guessed:
                    self.assertIn(f'Карта осталась у <a href="tg://user?id={outcome.receiver_id}">{receiver}</a>.', text)
                    self.assertIn('<a href="tg://user?id=202">Voter</a> угадывает.', text)
                else:
                    self.assertEqual(outcome.receiver_id, 202)
                    self.assertIn('<a href="tg://user?id=202">Voter</a> ошибается, карта переходит этому игроку.', text)
                self.assertNotIn("Игрок", text)
                self.assertNotIn("(id:", text)

    def test_names_cannot_inject_markup_or_redirect_profile_links(self):
        class ParsedLinks(HTMLParser):
            def __init__(self):
                super().__init__()
                self.links = []
                self.text = []
            def handle_starttag(self, tag, attrs):
                self.links.append((tag, dict(attrs).get("href")))
            def handle_data(self, data):
                self.text.append(data)

        name = '<b>Валерия</b> & "V"'
        voter = '<a href="https://example.com">leru</a>'
        turn = PublicTurn("test", -100123, None, 101, name, ConfirmedMove("6 ♠", "6 ♥", False),
                          voter_id=202, voter_name=voter, vote="yes", match_id="party",
                          expected_voter_id=202, expected_voter_name=voter)
        for text in (claim_text(turn), result_text(turn)):
            parser = ParsedLinks()
            parser.feed(text)
            self.assertIn(name, "".join(parser.text))
            self.assertIn(voter, "".join(parser.text))
            self.assertTrue(parser.links)
            self.assertTrue(all((tag == "a" and href in {"tg://user?id=101", "tg://user?id=202"}) or (tag == "b" and href is None)
                                for tag, href in parser.links))

    def test_packaged_stickers_cover_the_deck_and_are_webp_under_size_limit(self):
        assets = lab.ROOT / "assets" / "stickers"
        expected = {"card_back.webp"} | {card_filename(card) for card in DECK}
        self.assertEqual({p.name for p in assets.glob("*.webp")}, expected)
        for name in expected:
            with self.subTest(name=name):
                data = (assets / name).read_bytes()
                self.assertEqual(data[:4], b"RIFF")
                self.assertEqual(data[8:12], b"WEBP")
                self.assertLess(len(data), 512 * 1024)


class PublicTurnTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.store = PublicLab(Path("offline-test-assets"))
        self.replacement = patch.object(lab, "public_lab", self.store)
        self.replacement.start()
        self.addCleanup(self.replacement.stop)
        lab.views.clear()
        self.bot = AsyncMock()
        self.next_id = 100
        self.bot.send_sticker.side_effect = self.sent
        self.bot.send_message.side_effect = self.sent

    async def asyncTearDown(self):
        tasks = list(lab.receipt_tasks)
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        lab.receipt_tasks.clear()
        lab.views.clear()

    async def sent(self, **kwargs):
        self.next_id += 1
        return SimpleNamespace(message_id=self.next_id, ephemeral_message_id=700,
                               sticker=SimpleNamespace(file_id=f"offline-sticker-{self.next_id}"))

    def turn(self, chat_id=-100123):
        return self.store.create_turn(chat_id, 777, 101, "Author", ConfirmedMove("6 ♠", "6 ♥", False))

    def network_error(self):
        return TelegramNetworkError(method=SendMessage(chat_id=-100123, text="test"), message="offline")

    async def open(self):
        await lab.open_hand(query(data="lab3:open").as_(self.bot), self.bot)
        return lab.views[(-100123, 101)]

    def choice(self, view, action, value=None):
        data = f"lab3:{action}:{view.nonce}:{view.revision}"
        if value is not None:
            data += f":{value}"
        return query(data=data, ephemeral_id=700).as_(self.bot)

    async def click(self, action, value=None):
        view = lab.views[(-100123, 101)]
        await lab.update_selection(self.choice(view, action, value), self.bot)
        return lab.views[(-100123, 101)]

    async def review(self):
        view = await self.open()
        await self.click("select", 0)
        return await self.click("claim", (DECK.index(view.cards[0]) + 1) % 36)

    def vote_callback(self, turn, user_id=202, vote="no", chat_id=-100123, message_id=None):
        callback = query(user_id=user_id, chat_id=chat_id, data=f"lab3:vote:{turn.token}:{vote}")
        message = callback.message.model_copy(update={"message_id": message_id or turn.claim_id})
        return callback.model_copy(update={"message": message}).as_(self.bot)

    async def test_publication_has_back_and_claim_but_never_real_card_or_truth(self):
        turn = self.turn()
        await self.store.resume(self.bot, turn)
        self.assertEqual(self.bot.send_sticker.await_count, 1)
        self.assertEqual(Path(self.bot.send_sticker.call_args.kwargs["sticker"].path).name, "card_back.webp")
        args = self.bot.send_message.call_args.kwargs
        self.assertIn("6 ♥", args["text"])
        self.assertNotIn("6 ♠", args["text"])
        self.assertNotIn("БЛЕФ", args["text"])
        self.assertEqual([b.text for b in args["reply_markup"].inline_keyboard[0]], ["Верю", "Не верю"])
        self.assertEqual(args["message_thread_id"], 777)
        self.assertEqual(args["parse_mode"], "HTML")
        self.assertTrue(args["link_preview_options"].is_disabled)
        self.assertNotIn("ephemeral_message_parameters", args)
        self.assertIsNone(turn.face_id)

    async def test_author_and_bots_cannot_vote(self):
        turn = self.turn()
        await self.store.publish(self.bot, turn)
        for user_id, is_bot in ((101, False), (303, True)):
            with self.subTest(user_id=user_id), self.assertRaises(PublicTurnError):
                self.store.accept_vote(turn, user_id, "Tester", is_bot, "yes")
        self.assertIsNone(turn.vote)
        self.assertIsNone(turn.face_id)

    async def test_first_vote_is_fixed_before_reveal_and_cannot_be_changed(self):
        turn = self.turn()
        await self.store.publish(self.bot, turn)
        self.store.accept_vote(turn, 202, "Voter", False, "no")
        for voter, vote in ((303, "yes"), (202, "yes")):
            with self.subTest(voter=voter), self.assertRaises(PublicTurnError):
                self.store.accept_vote(turn, voter, "Tester", False, vote)
        self.assertEqual(turn.vote, "no")
        self.assertEqual(turn.voter_id, 202)
        await self.store.resume(self.bot, turn)
        self.assertTrue(turn.finished)
        self.assertEqual(turn.outcome.receiver_id, 101)
        self.assertIn('Карта осталась у <a href="tg://user?id=101">Author</a>', self.bot.send_message.call_args.kwargs["text"])
        self.assertEqual(self.bot.send_message.call_args.kwargs["parse_mode"], "HTML")

    async def test_reveal_removes_keyboard_and_sends_real_sticker_then_result_once(self):
        turn = self.turn()
        await self.store.publish(self.bot, turn)
        self.store.accept_vote(turn, 202, "Voter", False, "yes")
        await self.store.resume(self.bot, turn)
        self.bot.edit_message_reply_markup.assert_awaited_once_with(
            chat_id=-100123, message_id=turn.claim_id, reply_markup=None)
        self.assertEqual(Path(self.bot.send_sticker.call_args.kwargs["sticker"].path).name, "spades_6.webp")
        self.assertIn("БЛЕФ", self.bot.send_message.call_args.kwargs["text"])
        self.assertEqual(turn.outcome.receiver_id, 202)
        await self.store.resume(self.bot, turn)
        self.assertEqual(self.bot.send_sticker.await_count, 2)
        self.assertEqual(self.bot.send_message.await_count, 2)

    async def test_only_one_pending_turn_per_group(self):
        turn = self.turn()
        with self.assertRaises(PublicTurnError):
            self.turn()
        self.assertNotEqual(self.turn(chat_id=-100456).token, turn.token)
        turn.created_at -= TURN_TTL + 1
        self.assertNotEqual(self.turn().token, turn.token)

    async def test_expired_turn_never_reveals_card(self):
        turn = self.turn()
        await self.store.publish(self.bot, turn)
        turn.created_at -= TURN_TTL + 1
        with self.assertRaises(PublicTurnError):
            self.store.accept_vote(turn, 202, "Voter", False, "no")
        self.assertEqual(self.bot.send_sticker.await_count, 1)

    async def test_partial_publication_retries_only_the_unacknowledged_step(self):
        turn = self.turn()
        self.bot.send_message.side_effect = self.network_error()
        with self.assertRaises(TelegramNetworkError):
            await self.store.resume(self.bot, turn)
        self.assertIsNotNone(turn.back_id)
        self.assertIsNone(turn.claim_id)
        self.assertTrue(turn.delivery_failed)
        self.bot.send_message.side_effect = self.sent
        await self.store.resume(self.bot, turn)
        self.assertEqual(self.bot.send_sticker.await_count, 1)
        self.assertIsNotNone(turn.claim_id)

    async def test_partial_reveal_retry_keeps_first_vote_and_does_not_resend_face(self):
        turn = self.turn()
        await self.store.publish(self.bot, turn)
        self.store.accept_vote(turn, 202, "Voter", False, "no")
        self.bot.send_message.side_effect = self.network_error()
        with self.assertRaises(TelegramNetworkError):
            await self.store.resume(self.bot, turn)
        self.assertIsNotNone(turn.face_id)
        self.assertIsNone(turn.result_id)
        self.bot.send_message.side_effect = self.sent
        await self.store.resume(self.bot, turn)
        self.assertEqual(self.bot.send_sticker.await_count, 2)
        self.assertEqual(turn.voter_id, 202)
        self.assertTrue(turn.finished)

    async def test_failed_keyboard_removal_does_not_allow_second_vote(self):
        turn = self.turn()
        await self.store.publish(self.bot, turn)
        self.store.accept_vote(turn, 202, "Voter", False, "no")
        self.bot.edit_message_reply_markup.side_effect = self.network_error()
        await self.store.resume(self.bot, turn)
        self.assertTrue(turn.finished)
        with self.assertRaises(PublicTurnError):
            self.store.accept_vote(turn, 303, "Other", False, "yes")

    async def test_confirmation_publishes_once_and_blocks_new_choice_until_vote(self):
        review = await self.review()
        confirm = self.choice(review, "confirm")
        await lab.update_selection(confirm, self.bot)
        confirmed = lab.views[(-100123, 101)]
        self.assertEqual(confirmed.selection.phase, Phase.CONFIRMED)
        self.assertEqual(len(self.store.turns), 1)
        self.assertEqual(self.bot.send_sticker.await_count, 1)
        await lab.update_selection(confirm, self.bot)
        await self.click("new")
        self.assertIs(lab.views[(-100123, 101)], confirmed)
        self.assertEqual(self.bot.send_sticker.await_count, 1)

    async def test_private_edit_failure_never_rolls_back_an_already_public_move(self):
        await self.review()
        self.bot.edit_ephemeral_message_text.side_effect = self.network_error()
        confirmed = await self.click("confirm")
        self.assertEqual(confirmed.selection.phase, Phase.CONFIRMED)
        self.assertIsNotNone(self.store.turns[confirmed.public_turn_id].claim_id)
        self.assertEqual(len(self.store.turns), 1)

    async def test_vote_callback_rejects_wrong_group_and_message_then_reveals_once(self):
        turn = self.turn()
        await self.store.publish(self.bot, turn)
        await lab.vote_public(self.vote_callback(turn, chat_id=-100456), self.bot)
        await lab.vote_public(self.vote_callback(turn, message_id=999), self.bot)
        await lab.vote_public(self.vote_callback(turn, user_id=101), self.bot)
        self.assertIsNone(turn.vote)
        await lab.vote_public(self.vote_callback(turn), self.bot)
        self.assertTrue(turn.finished)
        await lab.vote_public(self.vote_callback(turn), self.bot)
        self.assertEqual(self.bot.send_sticker.await_count, 2)

    async def test_new_test_move_is_available_after_public_result(self):
        await self.review()
        confirmed = await self.click("confirm")
        turn = self.store.turns[confirmed.public_turn_id]
        await lab.vote_public(self.vote_callback(turn), self.bot)
        view = await self.click("new")
        self.assertEqual(view.selection.phase, Phase.HAND)
        self.assertIsNone(view.public_turn_id)


if __name__ == "__main__":
    unittest.main()
