"""Experiment 2: gameplay choices, stale callbacks and private-only rendering."""

import asyncio
from dataclasses import FrozenInstanceError
from types import SimpleNamespace
import unittest
from unittest.mock import AsyncMock

from aiogram.exceptions import TelegramNetworkError
from aiogram.methods import EditEphemeralMessageText
from aiogram.types import User

import main as lab
from card_selection import (
    DECK, Phase, Selection, SelectionError, advance_selection, selection_keyboard,
)
from test_experiment import query

HAND = (DECK[0], DECK[8], DECK[9], DECK[17], DECK[35])


class SelectionRulesTests(unittest.TestCase):
    def test_all_real_and_declared_pairs_use_exact_card_match(self):
        for real in DECK:
            for index, declared in enumerate(DECK):
                with self.subTest(real=real, declared=declared):
                    cards = (real,)
                    state = advance_selection(Selection(), cards, "select", 0)
                    state = advance_selection(state, cards, "claim", index)
                    self.assertIsNone(state.confirmed)
                    state = advance_selection(state, cards, "confirm")
                    self.assertEqual(state.confirmed.real_card, real)
                    self.assertEqual(state.confirmed.declared_card, declared)
                    self.assertEqual(state.confirmed.is_truth, real == declared)

    def test_invalid_indices_and_confirm_before_both_choices_are_rejected(self):
        for action, value in (("confirm", None), ("claim", 0), ("select", -1), ("select", 5)):
            with self.subTest(action=action, value=value), self.assertRaises(SelectionError):
                advance_selection(Selection(), HAND, action, value)
        state = advance_selection(Selection(), HAND, "select", 0)
        for action, value in (("confirm", None), ("claim", -1), ("claim", 36)):
            with self.subTest(action=action, value=value), self.assertRaises(SelectionError):
                advance_selection(state, HAND, action, value)

    def test_change_real_clears_the_previous_declaration(self):
        state = advance_selection(Selection(), HAND, "select", 0)
        state = advance_selection(state, HAND, "claim", 35)
        state = advance_selection(state, HAND, "change_real")
        self.assertEqual(state, Selection())

    def test_change_declaration_keeps_the_real_card(self):
        state = advance_selection(Selection(), HAND, "select", 2)
        state = advance_selection(state, HAND, "claim", 0)
        state = advance_selection(state, HAND, "change_claim")
        self.assertEqual(state.phase, Phase.DECLARE)
        self.assertEqual(state.real_index, 2)
        self.assertIsNone(state.declared_index)

    def test_cancel_discards_unconfirmed_choices(self):
        state = advance_selection(Selection(), HAND, "select", 0)
        state = advance_selection(state, HAND, "claim", 35)
        self.assertEqual(advance_selection(state, HAND, "cancel"), Selection())

    def test_confirmation_cannot_be_changed_or_confirmed_twice(self):
        state = advance_selection(Selection(), HAND, "select", 0)
        state = advance_selection(state, HAND, "claim", 0)
        state = advance_selection(state, HAND, "confirm")
        with self.assertRaises(FrozenInstanceError):
            state.confirmed.is_truth = False
        for action in ("confirm", "change_real", "change_claim", "cancel"):
            with self.subTest(action=action), self.assertRaises(SelectionError):
                advance_selection(state, HAND, action)
        self.assertEqual(advance_selection(state, HAND, "new"), Selection())

    def test_declaration_keyboard_contains_all_36_cards_and_short_callback_data(self):
        state = advance_selection(Selection(), HAND, "select", 0)
        keyboard = selection_keyboard(state, HAND, "abcdefgh", 123)
        buttons = [button for row in keyboard.inline_keyboard for button in row]
        cards = [button for button in buttons if button.callback_data.startswith("lab2:claim:")]
        self.assertEqual({button.text for button in cards}, set(DECK))
        self.assertEqual(len(cards), 36)
        self.assertEqual({int(button.callback_data.split(":")[-1]) for button in cards}, set(range(36)))
        self.assertTrue(all(len(button.callback_data.encode("utf-8")) <= 64 for button in buttons))


class SelectionTelegramTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        lab.views.clear()
        self.bot = AsyncMock()
        self.bot.send_message.return_value = SimpleNamespace(ephemeral_message_id=700)

    async def asyncTearDown(self):
        tasks = list(lab.receipt_tasks)
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        lab.receipt_tasks.clear()
        lab.views.clear()

    async def open(self):
        await lab.open_hand(query(data="lab2:open").as_(self.bot), self.bot)
        return lab.views[(-100123, 101)]

    def callback(self, view, action, value=None, **kwargs):
        data = f"lab2:{action}:{view.nonce}:{view.revision}"
        if value is not None:
            data += f":{value}"
        return query(data=data, ephemeral_id=700, **kwargs).as_(self.bot)

    async def click(self, action, value=None):
        view = lab.views[(-100123, 101)]
        await lab.update_selection(self.callback(view, action, value), self.bot)
        return lab.views[(-100123, 101)]

    async def review(self, truth=True):
        view = await self.open()
        await self.click("select", 0)
        index = DECK.index(view.cards[0])
        return await self.click("claim", index if truth else (index + 1) % 36)

    async def test_truthful_flow_stays_in_the_same_private_window(self):
        await self.review()
        view = await self.click("confirm")
        self.assertEqual(view.selection.phase, Phase.CONFIRMED)
        self.assertTrue(view.selection.confirmed.is_truth)
        args = self.bot.edit_ephemeral_message_text.call_args.kwargs
        self.assertEqual(args["receiver_user_id"], 101)
        self.assertEqual(args["chat_id"], -100123)
        self.assertEqual(args["ephemeral_message_id"], 700)
        self.assertIn("Правда: карты совпали", args["text"])
        self.assertEqual(self.bot.send_message.await_count, 1)
        self.assertEqual(self.bot.edit_ephemeral_message_text.await_count, 3)
        self.bot.edit_message_text.assert_not_awaited()
        self.bot.send_sticker.assert_not_awaited()

    async def test_bluff_flow_reports_bluff_privately(self):
        await self.review(truth=False)
        view = await self.click("confirm")
        self.assertFalse(view.selection.confirmed.is_truth)
        self.assertIn("Блеф: карты не совпали", self.bot.edit_ephemeral_message_text.call_args.kwargs["text"])

    async def test_repeated_confirmation_callback_is_ignored(self):
        view = await self.review()
        callback = self.callback(view, "confirm")
        await lab.update_selection(callback, self.bot)
        confirmed = lab.views[(-100123, 101)]
        count = self.bot.edit_ephemeral_message_text.await_count
        await lab.update_selection(callback, self.bot)
        self.assertIs(lab.views[(-100123, 101)], confirmed)
        self.assertEqual(self.bot.edit_ephemeral_message_text.await_count, count)

    async def test_confirming_from_initial_step_does_not_create_a_move(self):
        await self.open()
        view = await self.click("confirm")
        self.assertIsNone(view.selection.confirmed)
        self.bot.edit_ephemeral_message_text.assert_not_awaited()

    async def test_failed_confirmation_can_be_retried_without_losing_choices(self):
        review = await self.review()
        self.bot.edit_ephemeral_message_text.side_effect = TelegramNetworkError(
            method=EditEphemeralMessageText(chat_id=-100123, receiver_user_id=101,
                                            ephemeral_message_id=700, text="test"), message="test")
        view = await self.click("confirm")
        self.assertEqual(view.selection.phase, Phase.REVIEW)
        self.assertEqual(view.revision, review.revision)
        self.assertIsNone(view.selection.confirmed)
        self.assertEqual(self.bot.send_message.await_count, 1)
        self.bot.edit_ephemeral_message_text.side_effect = None
        view = await self.click("confirm")
        self.assertEqual(view.selection.phase, Phase.CONFIRMED)

    async def test_other_user_group_and_receiver_cannot_confirm(self):
        view = await self.review()
        self.bot.edit_ephemeral_message_text.reset_mock()
        for kwargs in ({"user_id": 202}, {"chat_id": -100456}, {"chat_id": 101},
                       {"receiver": User(id=202, is_bot=False, first_name="Other")}):
            with self.subTest(kwargs=kwargs):
                await lab.update_selection(self.callback(view, "confirm", **kwargs), self.bot)
        self.bot.edit_ephemeral_message_text.assert_not_awaited()
        self.assertIsNone(view.selection.confirmed)

    async def test_reopening_keeps_confirmed_move_and_changes_window_nonce(self):
        await self.review()
        confirmed = await self.click("confirm")
        confirmed.created_at -= 3
        reopened = await self.open()
        self.assertEqual(reopened.selection, confirmed.selection)
        self.assertEqual(reopened.cards, confirmed.cards)
        self.assertNotEqual(reopened.nonce, confirmed.nonce)
        await lab.update_selection(self.callback(confirmed, "new"), self.bot)
        self.assertIs(lab.views[(-100123, 101)], reopened)

    async def test_new_test_move_keeps_hand_and_resets_both_choices(self):
        await self.review()
        confirmed = await self.click("confirm")
        view = await self.click("new")
        self.assertEqual(view.cards, confirmed.cards)
        self.assertEqual(view.selection, Selection())


if __name__ == "__main__":
    unittest.main()
