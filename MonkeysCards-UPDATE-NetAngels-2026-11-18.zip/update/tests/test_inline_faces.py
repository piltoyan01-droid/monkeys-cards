"""Face thumbnails are private previews; Telegram sends only overridden text."""

from pathlib import Path
from types import SimpleNamespace
import unittest
from tempfile import TemporaryDirectory
from unittest.mock import AsyncMock

from aiogram.exceptions import TelegramNetworkError, TelegramBadRequest
from aiogram.methods import GetStickerSet
from aiogram.types import FSInputFile, InlineQuery, InlineQueryResultCachedSticker, User

from card_selection import DECK
from inline_faces import InlineFaces, parse_declaration
from inline_mode import InlineLab, InlinePanel
from public_turn import PublicLab, card_filename


class DeclarationTests(unittest.TestCase):
    def test_all_36_cards_parse_and_variation_selectors_are_accepted(self):
        for card in DECK:
            with self.subTest(card=card):
                self.assertEqual(parse_declaration("=" + card), card)
                self.assertEqual(parse_declaration("=" + card + "\ufe0f"), card)

    def test_russian_and_latin_aliases(self):
        aliases = {"=6пик": "6 ♠", "=пики6": "6 ♠", "=ТУЗ ЧЕРВЕЙ": "A ♥",
                   "=валетбубны": "J ♦", "=10треф": "10 ♣", "=Qh": "Q ♥", "=6❤️": "6 ♥"}
        for text, card in aliases.items():
            with self.subTest(text=text):
                self.assertEqual(parse_declaration(text), card)

    def test_incomplete_and_invalid_declarations_are_rejected(self):
        for text in ("=", "=6", "=5♠", "=11♥", "=joker", "=A?", "=6♠ 7♥"):
            with self.subTest(text=text):
                self.assertIsNone(parse_declaration(text))


class FacePreviewTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.cards = tuple(DECK[:5])
        temporary = TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.public = PublicLab(Path(temporary.name) / "stickers")
        self.flow = InlineLab(lambda: self.public, lambda chat, user: self.cards)
        self.panel = InlinePanel("faces-panel", -100123, None, 42, chat_instance="group")
        self.flow.panels[self.panel.token] = self.panel
        self.bot = AsyncMock()
        self.bot.id = 777

        self.bot.get_me.return_value = SimpleNamespace(id=777, username="LabTestBot")
        self.pack = SimpleNamespace(stickers=[SimpleNamespace(file_id="registered-" + card_filename(card),
            file_unique_id=f"unique-{index}", is_animated=False, is_video=False) for index, card in enumerate(DECK)])
        self.bot.get_sticker_set.return_value = self.pack

    def query(self, suffix=""):
        return InlineQuery(id="query", from_user=User(id=101, is_bot=False, first_name="Tester"),
                           query=f"lab4 {self.panel.token} {suffix}".strip(), offset="", chat_type="supergroup").as_(self.bot)

    async def test_real_stickers_are_loaded_without_messages_or_raw_upload_ids(self):
        self.assertTrue(await self.flow.prepare_faces(self.bot, 101, self.cards))
        self.bot.get_sticker_set.assert_awaited_once_with("lab_faces_v1_by_LabTestBot")
        self.bot.upload_sticker_file.assert_not_awaited()
        self.assertEqual(self.flow.faces.ids[self.cards[0]], self.pack.stickers[0].file_id)
        self.bot.send_message.assert_not_awaited()
        self.bot.send_photo.assert_not_awaited()
        self.bot.send_sticker.assert_not_awaited()
        self.bot.create_new_sticker_set.assert_not_awaited()

    async def test_registered_faces_are_cached(self):
        await self.flow.prepare_faces(self.bot, 101, self.cards)
        await self.flow.prepare_faces(self.bot, 101, self.cards)
        self.bot.get_sticker_set.assert_awaited_once()

    async def test_missing_set_is_created_for_human_owner_with_36_faces(self):
        self.bot.get_sticker_set.side_effect = [TelegramBadRequest(
            method=GetStickerSet(name="offline"), message="STICKERSET_INVALID"), self.pack]
        self.assertTrue(await self.flow.prepare_faces(self.bot, 101, self.cards))
        args = self.bot.create_new_sticker_set.call_args.kwargs
        self.assertEqual(args["user_id"], 101)
        self.assertEqual(len(args["stickers"]), 36)
        self.assertTrue(all(Path(sticker.sticker.path).name != "card_back.webp" for sticker in args["stickers"]))
        self.bot.send_sticker.assert_not_awaited()

    async def test_no_set_creation_during_time_limited_inline_query(self):
        self.bot.get_sticker_set.side_effect = TelegramBadRequest(
            method=GetStickerSet(name="offline"), message="STICKERSET_INVALID")
        await self.flow.answer_query(self.query())
        self.assertEqual(self.bot.call_args.args[0].results, [])
        self.bot.create_new_sticker_set.assert_not_awaited()

    async def test_manifest_keeps_card_mapping_when_pack_is_reordered(self):
        self.assertTrue(await self.flow.prepare_faces(self.bot, 101, self.cards))
        original = dict(self.flow.faces.ids)
        self.flow.faces.ids.clear()
        self.public.sticker_ids.clear()
        self.pack.stickers.reverse()
        self.assertTrue(await self.flow.prepare_faces(self.bot, 101, self.cards))
        self.assertEqual(self.flow.faces.ids, original)

    async def test_already_sent_valid_faces_can_be_reused_without_a_set(self):
        for index, card in enumerate(self.cards):
            self.public.sticker_ids[card_filename(card)] = f"sent-{index}"
        self.assertTrue(await self.flow.prepare_faces(self.bot, 101, self.cards))
        self.bot.get_sticker_set.assert_not_awaited()

    async def test_grid_contains_faces_in_hand_order_with_text_override_on_every_result(self):
        await self.flow.prepare_faces(self.bot, 101, self.cards)
        results = self.flow.build_results(self.query("=A♥"))
        self.assertEqual(len(results), len(self.cards))
        for index, result in enumerate(results):
            self.assertIsInstance(result, InlineQueryResultCachedSticker)
            self.assertEqual(result.sticker_file_id, self.flow.faces.ids[self.cards[index]])
            self.assertIsNotNone(result.input_message_content)
            self.assertEqual(result.input_message_content.parse_mode, "HTML")
            self.assertTrue(result.input_message_content.link_preview_options.is_disabled)
            text = result.input_message_content.message_text
            self.assertIn("Заявленная карта: A ♥", text)
            self.assertNotIn(self.cards[index], text)
            self.assertNotIn(result.sticker_file_id, text)
            proposal, _ = self.flow.get_proposal(result.id, 101)
            self.assertEqual(proposal.real_index, index)
            self.assertEqual(proposal.declared_index, DECK.index("A ♥"))

    async def test_without_declaration_each_clicked_face_is_a_truthful_choice(self):
        await self.flow.prepare_faces(self.bot, 101, self.cards)
        results = self.flow.build_results(self.query())
        for result in results:
            proposal, session = self.flow.get_proposal(result.id, 101)
            self.assertEqual(session.cards[proposal.real_index], DECK[proposal.declared_index])

    async def test_first_query_can_prepare_faces_lazily_without_chat_posts(self):
        await self.flow.answer_query(self.query("=6пик"))
        method = self.bot.call_args.args[0]
        self.assertEqual(len(method.results), 5)
        self.assertTrue(all(isinstance(result, InlineQueryResultCachedSticker) for result in method.results))
        self.assertTrue(method.is_personal)
        self.assertEqual(method.cache_time, 0)
        self.bot.send_message.assert_not_awaited()

    async def test_upload_failure_does_not_fall_back_to_posting_secret_faces(self):
        self.bot.get_sticker_set.side_effect = TelegramNetworkError(
            method=GetStickerSet(name="offline"), message="offline")
        self.assertFalse(await self.flow.prepare_faces(self.bot, 101, self.cards))
        self.assertEqual(self.flow.build_results(self.query()), [])
        self.bot.send_photo.assert_not_awaited()
        self.bot.send_sticker.assert_not_awaited()
        self.bot.send_message.assert_not_awaited()


if __name__ == "__main__":
    unittest.main()
