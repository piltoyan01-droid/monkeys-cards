"""Shared settings, private delivery, owner binding, and stale button protection."""

from datetime import datetime, timezone
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import unittest
from unittest.mock import AsyncMock

from aiogram.exceptions import TelegramForbiddenError
from aiogram.methods import SendMessage
from aiogram.types import CallbackQuery, Chat, Message, User

from group_settings import GroupSettings, SettingsError, SettingsUI


class SettingsTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        directory = TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.path = Path(directory.name) / "preferences.json"
        self.store = GroupSettings(self.path)
        self.changed = AsyncMock()
        self.ui = SettingsUI(self.store, self.changed)
        self.bot = AsyncMock()
        self.bot.send_message.return_value = SimpleNamespace(message_id=50)
        self.bot.get_me.return_value = SimpleNamespace(username="LabTestBot")

    def message(self, chat=-100123, user=101, text="/settings"):
        return Message(message_id=50, date=datetime.now(timezone.utc),
            chat=Chat(id=chat, type="private" if chat > 0 else "supergroup", title="Test <group>" if chat < 0 else None),
            from_user=User(id=user, is_bot=False, first_name="Tester"), text=text).as_(self.bot)

    def callback(self, data, user=101):
        return CallbackQuery(id="callback", from_user=User(id=user, is_bot=False, first_name="Tester"),
            chat_instance="private", message=self.message(chat=user, user=user), data=data).as_(self.bot)

    def test_persistence_group_isolation_and_last_mode_guard(self):
        self.store.set_mode(-100123, "inline", False, 0)
        loaded = GroupSettings(self.path)
        self.assertFalse(loaded.get(-100123).inline)
        self.assertTrue(loaded.get(-100456).inline)
        with self.assertRaises(SettingsError):
            loaded.set_mode(-100123, "ephemeral", False, 1)
        self.assertTrue(loaded.get(-100123).ephemeral)

    async def test_group_command_sends_panel_only_to_requesting_user(self):
        await self.ui.command(self.message(), self.bot)
        args = self.bot.send_message.call_args.kwargs
        self.assertEqual(args["chat_id"], 101)
        self.assertIn("Test &lt;group&gt;", args["text"])
        self.assertIn("инлайн-режим", args["text"])
        self.assertIn("эфемерное отображение", args["text"])

    async def test_unstarted_private_chat_uses_owner_bound_deep_link(self):
        self.bot.send_message.side_effect = TelegramForbiddenError(
            method=SendMessage(chat_id=101, text="settings"), message="Forbidden")
        await self.ui.command(self.message(), self.bot)
        panel = next(iter(self.ui.panels.values()))
        reply = self.bot.call_args.args[0]
        self.assertEqual(reply.reply_markup.inline_keyboard[0][0].url,
                         f"https://t.me/LabTestBot?start=settings_{panel.token}")
        self.bot.send_message.side_effect = None
        self.bot.send_message.reset_mock()
        await self.ui.start(self.message(chat=202, user=202, text=f"/start settings_{panel.token}"), self.bot)
        self.bot.send_message.assert_not_awaited()
        await self.ui.start(self.message(chat=101, text=f"/start settings_{panel.token}"), self.bot)
        self.assertEqual(self.bot.send_message.call_args.kwargs["chat_id"], 101)

    async def test_click_changes_shared_group_once_and_rejects_another_owner(self):
        await self.ui.command(self.message(), self.bot)
        panel = next(iter(self.ui.panels.values()))
        data = self.ui.keyboard(panel).inline_keyboard[0][0].callback_data
        await self.ui.change(self.callback(data, user=202), self.bot)
        self.assertTrue(self.store.get(panel.chat_id).inline)
        await self.ui.change(self.callback(data), self.bot)
        self.assertFalse(self.store.get(panel.chat_id).inline)
        self.changed.assert_awaited_once_with(self.bot, panel.chat_id)
        await self.ui.change(self.callback(data), self.bot)
        self.assertFalse(self.store.get(panel.chat_id).inline)
        self.assertEqual(self.changed.await_count, 1)

    async def test_other_group_panel_does_not_change_first_group(self):
        await self.ui.command(self.message(chat=-100123), self.bot)
        await self.ui.command(self.message(chat=-100456), self.bot)
        panel = list(self.ui.panels.values())[-1]
        await self.ui.change(self.callback(self.ui.keyboard(panel).inline_keyboard[1][0].callback_data), self.bot)
        self.assertFalse(self.store.get(-100456).ephemeral)
        self.assertTrue(self.store.get(-100123).ephemeral)

    def test_personal_preferences_persist_without_changing_other_players_or_groups(self):
        self.store.set_personal(101, "inline", 0)
        loaded = GroupSettings(self.path)
        self.assertTrue(loaded.effective(-100123, 101).inline)
        self.assertFalse(loaded.effective(-100123, 101).ephemeral)
        self.assertTrue(loaded.effective(-100123, 202).ephemeral)
        self.assertTrue(loaded.get(-100123).ephemeral)
        loaded.set_mode(-100123, "inline", False, 0)
        self.assertTrue(loaded.effective(-100123, 101).ephemeral)
        self.assertFalse(loaded.effective(-100123, 101).inline)
        self.assertTrue(loaded.effective(-100456, 101).inline)
        self.assertEqual(GroupSettings(self.path).personal(101).mode, "inline")

    async def test_private_personal_command_and_owner_bound_selection(self):
        refresh = AsyncMock()
        self.ui.on_personal_change = refresh
        await self.ui.personal_command(self.message(chat=101, text="/mysettings"), self.bot)
        panel = next(iter(self.ui.panels.values()))
        self.assertTrue(panel.personal)
        button = self.ui.keyboard(panel).inline_keyboard[1][0]
        await self.ui.change(self.callback(button.callback_data, user=202), self.bot)
        self.assertEqual(self.store.personal(101).mode, "group")
        await self.ui.change(self.callback(button.callback_data), self.bot)
        self.assertEqual(self.store.personal(101).mode, "inline")
        refresh.assert_awaited_once_with(self.bot, 101)
        self.changed.assert_not_awaited()
