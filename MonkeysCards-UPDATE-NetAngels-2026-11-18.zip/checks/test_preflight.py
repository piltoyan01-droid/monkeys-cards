"""Read-only update checks reject an unexpected base and unfinished games."""

import importlib.util
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

spec = importlib.util.spec_from_file_location("update_preflight", Path(__file__).resolve().parents[1] / "check_update.py")
preflight = importlib.util.module_from_spec(spec)
spec.loader.exec_module(preflight)


class PreflightTests(unittest.TestCase):
    def test_matching_base_accepts_line_ending_changes_without_modification(self):
        with TemporaryDirectory() as directory:
            root = Path(directory)
            main = b"# offline fixture\nprint(42)\n"
            (root / "main.py").write_bytes(main.replace(b"\n", b"\r\n"))
            (root / "games.json").write_text("{}", encoding="utf-8")
            preflight.check_target(root, preflight.source_hash(main))
            self.assertEqual((root / "main.py").read_bytes(), main.replace(b"\n", b"\r\n"))

    def test_changed_base_is_rejected(self):
        with TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "main.py").write_text("# another version", encoding="utf-8")
            with self.assertRaisesRegex(preflight.CheckFailed, "BASE_MAIN_MISMATCH"):
                preflight.check_target(root, preflight.source_hash(b"# expected version"))

    def test_unfinished_game_is_rejected_without_changing_it(self):
        with TemporaryDirectory() as directory:
            root = Path(directory)
            main = b"# offline fixture"
            (root / "main.py").write_bytes(main)
            saved = json.dumps({"group": {"status": "active"}})
            (root / "games.json").write_text(saved, encoding="utf-8")
            with self.assertRaisesRegex(preflight.CheckFailed, "SAVED_GAMES_NOT_EMPTY"):
                preflight.check_target(root, preflight.source_hash(main))
            self.assertEqual((root / "games.json").read_text(encoding="utf-8"), saved)

    def test_shipped_package_passes_its_checksums(self):
        package = Path(__file__).resolve().parents[1]
        metadata = preflight.check_package(package)
        self.assertEqual(metadata["expected_username"], "monkeysmafcardsbot")


if __name__ == "__main__":
    unittest.main()
